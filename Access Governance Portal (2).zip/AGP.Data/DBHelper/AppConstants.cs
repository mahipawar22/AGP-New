﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.DBHelper
{
    public class AppConstants
    {
        public static string ConnectionStringkey = "ConnectionStrings:AGPDB";
        public static string AGPToken = "AGPToken";
        public static string Authorization = "Authorization";
        public static string AGPPermission = "AGPPermission";

        public static string NoRecordFound = "No Record Found";
        public static string InsertSuccess = "Data inserted successfully";
        public static string UpdateSuccess = "Data updated successfully";
        public static string DeleteSuccess = "Data deleted successfully";
        public static string BadRequest = "Bad Request";
        public static string ActionSuccess = "Action performed successfully.";
        public static string ActionFailed = "Action failed.";
        public static string ErrorMessage = "Exception occured while performing the action, error: {0}.";
        public static string DuplicateRecordFound = "Duplicate Record Found";
        public const string Unknown_Exception_Message = "Something went wrong...";

        public const string successMessage = "Success: {0} Action performed successfully.";
        public const string failureMessage = "Fail: Something went wrong while executing {0} method/procedure.";

        #region request filter
        public static string EmployeeId = "EmployeeId";
        public static string Status = "Status";
        public static string FromDate = "FromDate";
        public static string ToDate = "ToDate";
        #endregion

        public static string SortDirection = "SortDirection";
        public static string SortColumn = "SortColumn";
        public static string PageSize = "PageSize";
        public static string PageNumber = "PageNumber";
        public static string SearchText = "SearchText";
        public static int PageSizeVal = 25;
        public static int PageNoVal = 1;

        public static DateTime DateTime = DateTime.Now;

        // Module Names
        public static string TrustedDomain = "TrustedDomain";
        public static string AccessRequest = "AccessRequest";
        public static string Account = "Account";
        public static string Dashboard = "Dashboard";
        public static string IncidentReport = "IncidentReport";
        public static string RequestReport = "RequestReport";
        public static string Roles = "Roles";
        public static string User = "User";
        public static string Login = "Login";
        

        // Actions
        public static string Create = "Create";
        public static string Update = "Update";
        public static string Delete = "Delete";
        public static string GetByID = "GetByID";
        public static string GetAll = "GetAll";
    
    }

    public class AppSettings
    {
        public static string ConnString = "ConnectionStrings:AGPDB";
    }
}
