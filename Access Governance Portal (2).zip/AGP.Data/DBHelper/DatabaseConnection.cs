﻿namespace AGP.Data.DBHelper
{
    public class DBConnection
    {
        public static string AGP_ConStr { get; set; }
        public static string Central_ConStr { get; set; }
        public static string TwoFA_OTPAuthURL { get; set; }
        public static int Enable_2FA { get; set; }
    }
}