﻿namespace AGP.Data.DBHelper
{
    public static class ProcedureDictionary
    {
        //----------- Trusted Domain Procedures -----------

        public const string sp_AGP_TrustedDomain_Create = "sp_AGP_TrustedDomain_Create";
        public const string sp_AGP_TrustedDomain_BulkInsert_Insert = "sp_AGP_TrustedDomain_BulkInsert_Insert";
        public const string sp_AGP_User_Login = "sp_AGP_User_Login";
        public const string sp_AGP_TrustedDomain_Delete = "sp_AGP_TrustedDomain_Delete";
        public const string sp_AGP_TrustedDomain_Update = "sp_AGP_TrustedDomain_Update";
        public const string sp_AGP_TrustedDomain_GetByCreatedBy = "sp_AGP_TrustedDomain_GetByCreatedBy";
        public const string sp_AGP_FH_TrustedDomain_GetByEmpId = "sp_AGP_FH_TrustedDomain_GetByEmpId";
        public const string sp_AGP_TrustedDomain_BulkUpdateStatus = "sp_AGP_TrustedDomain_BulkUpdateStatus";
        public const string sp_AGP_TrustedDomain_Get_Approved = "sp_AGP_TrustedDomain_Get_Approved";
        public const string sp_AGP_TrustedDomains_Get_Completed = "sp_AGP_TrustedDomains_Get_Completed";
        public const string sp_AGP_TrustedDomain_Get_Approved_ForIT = "sp_AGP_TrustedDomain_Get_Approved_ForIT";
        public const string sp_AGP_AllTrustedDomain_Draft = "sp_AGP_AllTrustedDomain_Draft";

        //----------- Access Request Procedures -----------
        public const string sp_AGP_AccessRequest_Create = "sp_AGP_AccessRequest_Create";
        public const string sp_AGP_AccessRequest_BulkInsert_Create = "sp_AGP_AccessRequest_BulkInsert_Create";
        public const string sp_AGP_AccessRequest_Update = "sp_AGP_AccessRequest_Update";
        public const string sp_AGP_AccessRequest_Delete = "sp_AGP_AccessRequest_Delete";
        public const string sp_AGP_AccessRequest_GetByEmployeeId = "sp_AGP_AccessRequest_GetByEmployeeId";
        public const string sp_AGP_AccessRequest_Id = "sp_AGP_AccessRequest_Id";
        public const string sp_AGP_GetAllAccessRequests_CreatedBy = "sp_AGP_GetAllAccessRequests_CreatedBy";
        public const string sp_AGP_FH_AccessRequest_GetByEmpId = "sp_AGP_FH_AccessRequest_GetByEmpId";
        public const string sp_AGP_AccessRequest_UpdateStatus = "sp_AGP_AccessRequest_UpdateStatus";
        public const string sp_AGP_AccessRequests_Get_Approved = "sp_AGP_AccessRequests_Get_Approved";
        public const string sp_AGP_AccessRequests_Get_Completed = "sp_AGP_AccessRequests_Get_Completed";
        public const string sp_AGP_AccessRequests_Get_Approved_ForIT = "sp_AGP_AccessRequests_Get_Approved_ForIT";
        public const string sp_AGP_GetAccessCategoryNames = "sp_AGP_GetAccessCategoryNames";
        public const string sp_AGP_Locations_GetAll = "sp_AGP_Locations_GetAll";
        public const string sp_AGP_GetAllDraftAccessRequests = "sp_AGP_GetAllDraftAccessRequests";
        //public const string sp_AGP_GetAllDraftAccessRequests = "sp_AGP_GetAllDraftAccessRequests_New";



        //----------- Request Procedures -----------
        public const string sp_AGP_EmployeeRequests_GetAll = "sp_AGP_EmployeeRequests_GetAll";

        //----------- Dashboard Procedures -----------
        public const string sp_AGP_User_Dashbaord_GetById = "sp_AGP_User_Dashbaord_GetById";

        //-----------Dlp Report Procedures-----------
        public const string sp_AGP_DLPIncidents_GetByDate = "sp_AGP_DLPIncidents_GetByDate";
        public const string sp_AGP_FH_GetAllDLPIncidentReport = "sp_AGP_FH_GetAllDLPIncidentReport";
        public const string sp_AGP_DlpIncidentsByEmployeeId = "sp_AGP_DlpIncidentsByEmployeeId";
        public const string sp_AGP_DLPIncident_UpdateJustificationBulk = "sp_AGP_DLPIncident_UpdateJustificationBulk";

        // Admin Roles Procedures
        public const string SP_AGP_GetRolesWithPermissions = "SP_AGP_GetRolesWithPermissions";
        public const string SP_AGP_GetPermissionsByRole = "SP_AGP_GetPermissionsByRole";
        public const string SP_AGP_CreateOrUpdateRolePermission = "SP_AGP_CreateOrUpdateRolePermission";
        public const string SP_AGP_RemoveRolePermission = "SP_AGP_RemoveRolePermission";
        public const string SP_AGP_GetMenus = "SP_AGP_GetMenus";
        public const string SP_AGP_GetRoles = "SP_AGP_GetRoles";
        public const string SP_AGP_GetPermissions = "SP_AGP_GetPermissions";

        // User Module Procedures
        public const string SP_AGP_Users_GetAll = "SP_AGP_Users_GetAll";
        public const string SP_AGP_Users_GetById = "SP_AGP_Users_GetById";
        public const string SP_AGP_Users_AssignRole = "SP_AGP_Users_AssignRole";
        public const string SP_AGP_DeactivatedUser = "SP_AGP_DeactivatedUser";
        public const string SP_AGP_AddUsersFromAscentMaster = "SP_AGP_AddUsersFromAscentMaster";
        public const string SP_AGP_GetEmployeeFromAscent = "SP_AGP_GetEmployeeFromAscent";

        //AuditLog
        public const string sp_AGP_AuditLog_Insert = "sp_AGP_AuditLog_Insert";

    }
}
