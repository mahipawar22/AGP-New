﻿using Microsoft.EntityFrameworkCore;

namespace AGP.Data.DataContext
{
    public class AGPDBContext : DbContext
    {
        public AGPDBContext()
        {
        }

        public AGPDBContext(DbContextOptions<AGPDBContext> options) : base(options)
        {
        }

    }
}
