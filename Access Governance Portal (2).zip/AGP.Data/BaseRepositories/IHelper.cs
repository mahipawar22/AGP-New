﻿using AGP.Data.ViewModels;

namespace AGP.Data.BaseRepositories
{
    public interface IHelper
    {
        UserSessionEntity GetLoggedInUser();
    }
}
