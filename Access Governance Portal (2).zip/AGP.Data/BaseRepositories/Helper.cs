﻿using AGP.Data.ViewModels;
using Microsoft.AspNetCore.Http;

namespace AGP.Data.BaseRepositories
{
    public class Helper : IHelper
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public Helper(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public UserSessionEntity GetLoggedInUser()
        {
            UserSessionEntity userSessionEntity = new UserSessionEntity() { UserId = 1,RoleId=1,Email="",UserName="",RoleName=""};
            var _entity = (UserSessionEntity)_httpContextAccessor.HttpContext.Items["User"];
            if (_entity != null)
                userSessionEntity = _entity;
            return userSessionEntity;
        }
    }
}
