﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq.Expressions;
using AGP.Data.ViewModels.BaseModels;

namespace AGP.Data.BaseRepositories
{
    public interface IRepository<TEntity> where TEntity : class
    {
        TEntity originalEntity { get; set; }

        TEntity Get(int id);

        Task<TEntity> GetAsync(int id);

        Task<TEntity> GetNoTrackingAsync(int id);

        TEntity GetNoTracking(int id);
        TEntity Get2(int id);

        Task<TEntity> GetAsync2(int id);
        //Task<SchemeAuditFieldResponse> GetAuditFields(int? TId);
        //Task<SchemeAuditFieldResponse> GetMasterSchemeAuditFields(int? masterSchemeId);

        Task<List<TEntity>> GetAllAsync();

        IEnumerable<TEntity> GetAll();
        IEnumerable<TEntity> GetAllMasterSchemes(int tssId, int schemeId);

        

        Task<TEntity> GetLastAsync(string propertyName);

        /// <summary>
        /// Without async will get object of entity
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        TEntity GetEntity(Expression<Func<TEntity, bool>> predicate);

        //IQueryable<TEntity> GetAllQueryMasterScheme(MasterSchemeSearchRequest model, out int totalCount);
        IQueryable<TEntity> GetAllQuery();

        IQueryable<TEntity> GetAllQuery2(int? pageNo, int? pageSize, out int totalCount);

        //IQueryable<TEntity> GetAllQuery3(SchemeSearchRequest model, out int totalCount);
        IQueryable<TEntity> GetAllQuery3(GlobalSearchRequest model, out int totalCount);
        IQueryable<TEntity> GetAllQuery4(GlobalSearchRequest model, out int totalCount);
        IQueryable<TEntity> GetAllQuery_Description(GlobalSearchRequest model, out int totalCount);
        
        //IQueryable<TEntity> MasterSchemeByFilters(MasterSchemeByIdRequest model);
        //IQueryable<TEntity> MasterSchemeByFilters(SchemeByIdRequest model);


        //IQueryable<TEntity> CentralDMPMOUSignedSearchFilter(CentralDMPMOUSignedSearchRequest model, out int totalCount);

        //IQueryable<TEntity> MasterAgriDomComboBonanzaSearchFilter(MasterAgriDomComboBonanzaSearchRequest model, out int totalCount);
        IEnumerable<TEntity> FindAll(Expression<Func<TEntity, bool>> predicate);

        Task<IEnumerable<TEntity>> FindAllAsync(Expression<Func<TEntity, bool>> predicate);

        Task<IEnumerable<TEntity>> Find(Expression<Func<TEntity, bool>> predicate);

        Task<TEntity> SingleOrDefault(Expression<Func<TEntity, bool>> predicate);

        void AddAsync(TEntity entity);
        TEntity AddAsyncDynamic(TEntity entity);
        void AddRange(IEnumerable<TEntity> entities);

        void AddRangeAsync(IEnumerable<TEntity> entities);

        void Remove(TEntity entity);

        void RemoveRange(IEnumerable<TEntity> entities);

        void UpdateAsync(TEntity entity, bool IsCreatedDateUpdate = false);

        Task<TResult> GetFirstOrDefaultAsync<TResult>(Expression<Func<TEntity, TResult>> selector,
                                              Expression<Func<TEntity, bool>> predicate = null,
                                              Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                                              Func<IQueryable<TEntity>, IIncludableQueryable<TEntity, object>> include = null,
                                              bool disableTracking = true);

        //Task<IEnumerable<TEntity>> GetAllAsync(params Expression<Func<TEntity, object>>[] includes);
        Task<IEnumerable<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includes);

        Task<TEntity> GetAsync(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includes);

        void UpdateGraph(TEntity entity, EntityState entityState);

        Task<IEnumerable<TEntity>> GetPagedSortedFilteredListAsync(int start, int length, string orderColumnName, ListSortDirection order, string searchValue);

        Task<int> GetRecordsTotalAsync();

        Task<int> GetRecordsFilteredAsync(string searchValue);

        string GetSearchPropertyName();

        bool Exists(Func<TEntity, bool> conditions);

        DataTable GetDataBySP(string SPName, List<string> ParamName = null, List<string> ParamValue = null);

        Task<DataTable> GetDataBySPAsync(string SPName, List<string> ParamName = null, List<object> ParamValue = null);

        Task<DataSet> GetDataSetBySP(string SPName, Dictionary<string, Object> parameters = null);

        Task<TEntity> GetAsync(long id);

        TEntity Get(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includes);

        void Add(TEntity entity);

        Task<TEntity> GetBySP(string SPName);

        Task<DataTable> GetBySP(string CommandText, CommandType commandType, SqlParameter[] sqlParameters);

        Task<DataSet> GetDataSetBySP(string CommandText, CommandType commandType, SqlParameter[] sqlParameters);

    }
}
