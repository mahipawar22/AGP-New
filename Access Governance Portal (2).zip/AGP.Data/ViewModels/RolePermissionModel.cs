﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels
{
    public class RolePermissionModel
    {
        public int MenuId { get; set; }
        public string MenuName { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public int? PermissionId { get; set; }   // Nullable because LEFT JOIN may return NULL
        public string PermissionName { get; set; }
    }
    public class RolePermissionRequest
    {
        public int? Id { get; set; }
        public int MenuId { get; set; }
        public int RoleId { get; set; }
        public int PermissionId { get; set; }
        public long UserId { get; set; }
    }


}
