﻿namespace AGP.Data.ViewModels.BaseModels
{
    public class GlobalResponse
    {
        public bool success { get; set; } = true;
        public string? message { get; set; }
        public string? errorMessage { get; set; } = null;
        public int? totalCount { get; set; }
        public object? data { get; set; }

        // public SchemeAuditFieldResponse auditFields { get; set; }
    }

    public class RequestReportResponse
    {
        public bool success { get; set; } = true;
        public string? message { get; set; }
        public string? errorMessage { get; set; } = null;
        public int? accessRequestCount { get; set; }
        public int? trustedDomainRequestCount { get; set; }
        public object? accessRequest { get; set; }

        public object? trustedDomainRequest { get; set; }
    }

    //Audit field area
    public class AuditFieldResponse
    {
        public int? Year { get; set; }

        public int? CreatedBy { get; set; }
        public string? CreatedByName { get; set; }
        public DateTime CreatedDate { get; set; }

        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string? ModifiedByName { get; set; }
    }

    public class GlobalSearchRequest
    {
        public int? pageNo { get; set; } = 1;
        public int? pageSize { get; set; } = 10000;
        public string? sortColumn { get; set; }
        public bool? sortDirection { get; set; }

        public int? id { get; set; }
        public string? searchText { get; set; }
    }
    public class GlobalSearchByIdRequest
    {
        public int? id { get; set; }
    }

    public class EmailNotificationRequestModel
    {
        public int? UserId { get; set; } = null;
        public int? SchemeId { get; set; } = null;
        public string? Email { get; set; } = null;
        public string? From { get; set; }
        public List<string> To { get; set; }
        public List<string> Cc { get; set; }
        public List<string> Bcc { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
    }

    public class RolePermission
    {
        public int Id { set; get; }
        public int Name { set; get; }
        public bool? IsActive { get; set; }
    }

    public class MenuAndPermission : MenuModel
    {
        public int Id { set; get; }
        public List<RolePermission> RolePermissions { get; set; }
    }

    public class RoleWithMenuAndPermission : MasterRoleModel
    {
        public List<MenuAndPermission> MenuAndPermissions { get; set; }
    }

}
