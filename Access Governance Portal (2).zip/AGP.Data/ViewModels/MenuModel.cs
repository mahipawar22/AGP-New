﻿namespace AGP.Data.ViewModels
{
    public class MenuByRoleModel
    {
        public int RoleId { get; set; }
        public int ModuleId { get; set; }
        public List<MenuModel> Menus { get; set; }
    }

    public class MenuModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string? Icon { get; set; }
        public int? ModuleId { get; set; }
        public string? Url { get; set; }
        public bool? IsActive { get; set; }
        public int? SortOrder { get; set; }
        public List<PermissionModel?> Permissions { get; set; } = null;
    }

    public class RolePermissionsModel
    {
        public int RoleId { get; set; }
        public List<PermissionModel> Permissions { get; set; }
    }

    public class PermissionModel
    {
        public int Id { get; set; }
        public int MenuId { get; set; }         
        public string? Name { get; set; }
        public string? Code { get; set; }
        public bool? IsActive { get; set; }
    }

}


