﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels
{
    public class TrustedDomainStatusUpdateRequest
    {
        public long Id { get; set; }
        public string Justification { get; set; }
        public string Email { get; set; }
    }
}
