﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels.TrustedDomain
{
    public class TrustedDomainStatusUpdate
    {
        public long Id { get; set; }
        public string Status { get; set; } = string.Empty;
        public string DLPStatus { get; set; } = string.Empty;
        public string? Justification { get; set; }
        public long ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; } = DateTime.UtcNow;
    }
}
