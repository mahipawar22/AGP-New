﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels
{
    //[JsonConverter(typeof(StringEnumConverter))]
    public enum WhitelistType
    {
        Temporary,
        Permanent
    }

    public class TrustedDomainUpsertRequest
    {
        public long Id { get; set; }
        public string DomainCompanyName { get; set; }
        public string RelationshipWithKSB { get; set; }

        [RegularExpression(@"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", 
            ErrorMessage = "Please enter a valid email address & Only letters, digits, '.', '_' and '@' are this special char are allowed")]
        public string DomainOrEmail { get; set; }
        public string WhitelistType { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Justification { get; set; }
        public DateTime? SubmissionDate { get; set; } 
        public DateTime? FHActionDate { get; set; }
        public long CreatedBy { get; set; }
        public long? ModifiedBy { get; set; }
        public int? AccessDurationInDays { get; set; }
        public string Status { get; set; }
        public string? DLPStatus { get; set; } 
        public string? Remark { get; set; }
        public string? SerialNumber { get; set; }
        public string? CreatedByEmail { get; set; }
    }




  
    public class TrustedDomainUpsertRequest1
    {
        public int Id { get; set; }
        public string CompanyName { get; set; }
      
    }
}
