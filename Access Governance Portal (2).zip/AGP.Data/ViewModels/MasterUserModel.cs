﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels
{
    public partial class MasterUserModel
    {
        public int Id { get; set; }
        public string? EmpFname { get; set; }
        public string? LastName { get; set; }
        public int RoleId { get; set; }
        public string Name { get; set; } = null!;
        public string Password { get; set; } = null!;

        //public int RoleId { get; set; }
        public string? RoleName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string? PhoneNo { get; set; }
        public bool? IsActive { get; set; }
        //public int? UserId { get; set; }
        public string? Address { get; set; }
        public DateTime? LastLoginDate { get; set; }
        public int? LoginFailedCount { get; set; }
        public int? Zone { get; set; }
        public int? Branch { get; set; }
        public int? TssDepartment { get; set; }
        public string? ZoneName { get; set; }
        public string? BranchName { get; set; }
        public string? TssName { get; set; }
        public string? Email { get; set; }
        public string? Permissions { get; set; }
        public List<UserPermissionModel> ListPermission { get; set; }
        public bool? IsTwoFactorEnabled { get; set; }
        public string? EmployeeId { get; set; }
        public string? ReportingEmpids { get; set; }
    }

    public static class PermissionHelper
    {
        public static List<UserPermissionModel> UserPermissionList { get; set; }
    }

    public partial class UserPermissionModel
    {
        public string Name { get; set; }
    }

    public partial class MasterUserLoginModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int RoleId { get; set; }
        public string UserToken { get; set; }
        public string? RoleName { get; set; }
        public string? Permissions { get; set; }
        public string? Email { get; set; }
        public DateTime VallidTo { get; set; }
        public string? LastName { get; set; }
        public string? FirstName { get; set; }
        public List<UserPermissionModel> ListPermission { get; set; }
        public bool? IsTwoFactorEnabled { get; set; }
    }
}
