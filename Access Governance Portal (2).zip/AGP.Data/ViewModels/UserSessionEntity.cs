﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels
{
    public partial class UserSessionEntity
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int RoleId { get; set; }
        public string UserToken { get; set; }
        public string? RoleName { get; set; }
        public string? Permissions { get; set; }
        public string? Email { get; set; }
        public DateTime VallidTo { get; set; }
        public string? LastName { get; set; }
        public string? FirstName { get; set; }
        public List<UserPermissionModel> ListPermission { get; set; }
        public bool? IsTwoFactorEnabled { get; set; }
        public string? EmployeeId { get; set; }
        public string? ReportingEmpids { get; set; }
    }
}
