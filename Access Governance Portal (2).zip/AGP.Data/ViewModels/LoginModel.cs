﻿namespace AGP.Data.ViewModels
{
    public class LoginModel
    {
        public string UserId { get; set; }
        public string? Password { get; set; }
        public bool IsSSO { get; set; } = false;
       // public int? isTwoFactorEnabled { get; set; }

    }

    public class ForgotPasswordModel
    {
        public string EmailId { get; set; }
    }

    public class ResetPasswordModel
    {
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string CPassword { get; set; }
    }
}
