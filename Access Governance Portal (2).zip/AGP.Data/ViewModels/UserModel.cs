﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels
{
    public class UserModel
    {
        public int Id { get; set; }
        public string EmployeeId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string DepartmentName { get; set; }
        public int RoleId { get; set; }
        public bool IsActive { get; set; }
        public long CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public long ModifiedBy { get; set; }
        public DateTime ModifiedOn { get; set; }
        public string Password { get; set; }
        public bool IsDeleted { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
    public class DeactivateUserRequest
    {
        public string EmployeeId { get; set; }
    }
    public class UpdateUserRole
    {
        public string EmployeeId { get; set; }
        public int RoleId { get; set; }
    }
    public class AddUserRequest
    {
        public string EmployeeId { get; set; }
        public string Name { get; set; }
        public int? RoleId { get; set; }
        public string Department { get; set; }
        public long CreatedBy { get; set; }
    }
    public class EmployeeResponse
    {
        public string EmployeeId { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
    }

}
