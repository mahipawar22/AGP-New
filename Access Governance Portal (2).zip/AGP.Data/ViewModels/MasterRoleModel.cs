﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels
{
    public class MasterRoleModel
    {
        public int Id { get; set; }
        public string? Roles { get; set; }
        public bool? IsActive { get; set; }
        public string? Code { get; set; }
    }
}
