﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels.RequestReportModel
{
    public class AccessRequestReportModel
    {
        public long Id { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeId { get; set; }
        public string DepartmentName { get; set; }
        public string Location { get; set; }
       // public int AccessCategoryId { get; set; }
        public string? AccessCategoryName { get; set; } 
        public string Reason { get; set; }
        public bool IsTemporaryAccess { get; set; }
        public int? AccessDurationInDays { get; set; }
        public string? UploadedFileName { get; set; }
        public string? UploadedFilePath { get; set; }
        public string Justification { get; set; }
        public string Remark { get; set; }
        public string Status { get; set; }
        public long CreatedBy { get; set; }
        public DateTime? AccessFromDate { get; set; }
        public DateTime? AccessToDate { get; set; }
        public DateTime? SubmissionDate { get; set; }
        public string SerialNumber { get; set; }   
        public DateTime? CreatedOn { get; set; }
        public DateTime? ActionDate { get; set; }
    }
}
