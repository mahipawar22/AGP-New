﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels.RequestReportModel
{
    public class EmployeeRequestModel
    {
        public string DepartmentName { get; set; } = "NA";
        public string Location { get; set; } = "NA";
        public string AccessCategoryName { get; set; } = "NA";  
        public string Justification { get; set; }
        public bool? IsTemporaryAccess { get; set; } 
        public int? AccessDurationInDays { get; set; }
        public DateTime? AccessFromDate { get; set; }
        public DateTime? AccessToDate { get; set; }
        public string DomainCompanyName { get; set; } = "NA";
        public string RelationshipWithKSB { get; set; } = "NA";
        public string DomainOrEmail { get; set; } = "NA";
        public string WhitelistType { get; set; } = "NA";
        public string Status { get; set; }
        public string CreatedBy { get; set; }  
    }
}
