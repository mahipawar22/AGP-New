﻿namespace AGP.Data.ViewModels.RequestReportModel
{
    public class RequestReportSummaryModel
    {
        public int? TotalAccessRequests { get; set; }
        public int? TotalTrustedDomainRequests { get; set; }
        public int? DraftAccessRequests { get; set; } 
        public int? DraftTrustedDomainRequests { get; set; } 
        public int? PendingAccessRequests { get; set; }
        public int? PendingTrustedDomainRequests { get; set; } 
        public int? ApprovedAccessRequests { get; set; } 
        public int? ApprovedTrustedDomainRequests { get; set; } 
        public int? RejectedAccessRequests { get; set; } 
        public int? RejectedTrustedDomainRequests { get; set; } 
    }
}
