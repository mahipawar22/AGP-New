﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels.RequestReportModel
{
    public class TrustedDomainReportModel
    {
        public long ?Id { get; set; }
        public string DomainCompanyName { get; set; }
        public string RelationshipWithKSB { get; set; }
        public string DomainOrEmail { get; set; }
        public string WhitelistType { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Justification { get; set; }
        public string Remark { get; set; }
        public string Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? AccessDurationInDays { get; set; }
        public string SerialNumber { get; set; }
        public DateTime? SubmissionDate { get; set; }
    }
}
