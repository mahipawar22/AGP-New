﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels.AccessRequest
{
    public class AccessCategories
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
    public class Locations
    {
        public int Id { get; set; }
        public string CityName { get; set; }
      
    }
}
