﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels.AccessRequest
{
    public class AccessRequestUpsertRequest
    {
        public long Id { get; set; }
        public string EmployeeName { get; set; } = string.Empty;
        public string EmployeeId { get; set; } = string.Empty;
        public string DepartmentName { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public int AccessCategoryId { get; set; }
        public string? AccessCategoryName { get; set; }
        public string Reason { get; set; } = string.Empty;
        public string? Justification { get; set; }
        public bool IsTemporaryAccess { get; set; }
        public int? AccessDurationInDays { get; set; }
        public string? UploadedFileName { get; set; }
        public string? UploadedFilePath { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public string? ITStatus { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool IsDeleted { get; set; }
        public long CreatedBy { get; set; }
        public DateTime? AccessFromDate { get; set; }
        public DateTime? AccessToDate { get; set; }
        public DateTime? FHActionDate { get; set; }
        public DateTime? SubmissionDate { get; set; }

        public string SerialNumber { get; set; }
        public string? CreatedByEmail { get; set; }
       // public string? CreatedByEmail { get; set; }
    }
}
