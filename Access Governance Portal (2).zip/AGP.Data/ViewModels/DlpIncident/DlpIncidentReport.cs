﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels.DlpIncident
{
    public class DlpIncidentReport
    {
       // public int Id { get; set; }
        public string Id { get; set; }  
        public long IncidentId { get; set; }
        public DateTime? IncidentTime { get; set; }
        public string SourceChannel { get; set; }
        public string Destination { get; set; }
        public string ActionTaken { get; set; }
        public decimal TransactionSize { get; set; }
        public string FileName { get; set; }
        public int UserId { get; set; }
        public string Location { get; set; }
        public int DepartmentId { get; set; }
        public int? FunctionalHeadId { get; set; }
        public string Acknowledgement { get; set; }
        public string Justification { get; set; }
        //public int CreatedBy { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        //public int ModifiedBy { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }  // Nullable DateTime
        public bool IsDeleted { get; set; }
        public string UserName { get; set; }
        public string DepartmentName { get; set; }
        public string FunctionalHeadName { get; set; }
        public string SourceEmailID { get; set; }
    }
    public class DlpIncidentReportNew
    {
        public int Id { get; set; }
        public string? IncidentId { get; set; }
        public DateTime? IncidentTime { get; set; }
        public string? SourceChannel { get; set; }
        public string? Destination { get; set; }
        public string? ActionTaken { get; set; }
        public int? TransactionSize { get; set; }
        public string? FileName { get; set; }
        public long? UserId { get; set; }
        public string? Location { get; set; }
        public int? DepartmentId { get; set; }
        public long? FunctionalHeadId { get; set; }
        public string? Acknowledgement { get; set; }
        public string? Justification { get; set; } //= string.Empty; // Required
        public long? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool IsDeleted { get; set; }
        public string? UserName { get; set; }
        public string? DepartmentName { get; set; }
        public string? FunctionalHeadName { get; set; }
        public string SourceEmailID { get; set; }
    }


}

