﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.ViewModels
{
    public class IncidentReportApprove
    {
        public List<int> Id { get; set; }
        public string? Justification { get; set; }

        public string? Acknowledgement { get; set; }
        public string? decision { get; set; }

        //  public DlpIncidentReport? dlpIncidentReport { get; set; }

    }
}
