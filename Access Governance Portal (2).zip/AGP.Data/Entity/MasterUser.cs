﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.Entity
{
    public class MasterUser
    {
        public int Id { get; set; }

        public string? UserName { get; set; }

        public string? Password { get; set; }

        public int UserRole { get; set; }

        public string? PhoneNo { get; set; }

        public string? EmailId { get; set; }

        public int? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public int? ModifiedBy { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public bool? IsActive { get; set; }

        public int? UserId { get; set; }

        public string? Cpassword { get; set; }

        public string? Address { get; set; }

        public DateTime? LastLoginDate { get; set; }

        public int? LoginFailedCount { get; set; }

        public int? Zone { get; set; }

        public int? Branch { get; set; }

        public int? TssDepartment { get; set; }

        public string? MultiSegmentHead { get; set; }

        public bool? IsPasswordUpdate { get; set; }

        public string? IsTerminated { get; set; }

        public bool? AccountLocked { get; set; }

        public bool? EmailConfirmed { get; set; }

        public bool? TwoFactorEnabled { get; set; }

        public string? Email { get; set; }

        public string? Mobile { get; set; }

        public string? TssDepartmentIds { get; set; }

    }
}
