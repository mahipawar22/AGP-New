﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.Entity
{
    public class MenuRolePermission
    {
        public int Id { get; set; }

        public int MenuId { get; set; }

        public int RoleId { get; set; }

        public int PermissionId { get; set; }

        public bool? IsActive { get; set; }

        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public int? ModifiedBy { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public virtual Menu Menu { get; set; } = null!;

        public virtual Permission Permission { get; set; } = null!;

        public virtual Role Role { get; set; } = null!;
    }
}
