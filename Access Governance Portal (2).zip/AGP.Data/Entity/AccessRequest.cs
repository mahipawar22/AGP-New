﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.Entity
{
    public class AccessRequest
    {
        public long Id { get; set; }
        public string EmployeeName { get; set; } = string.Empty;
        public string EmployeeId { get; set; } = string.Empty;
        public string DepartmentName { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public int AccessCategoryId { get; set; }
        public string Reason { get; set; } = string.Empty;
        public bool IsTemporaryAccess { get; set; }
        public int? AccessDurationInDays { get; set; }
        public string? UploadedFileName { get; set; }
        public string? UploadedFilePath { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool IsDeleted { get; set; }
        public long CreatedBy { get; set; }

        public DateTime? AccessFrom { get; set; }

        public DateTime? AccessTo { get; set; }
    }
}
