﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Data.Entity
{
    public class Role
    {
        public int Id { get; set; }

        public string? Roles { get; set; }

        public bool? IsActive { get; set; }

        public int? CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public int? ModifiedBy { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public bool? IsDeleted { get; set; }

        public DateTime? DeletedDate { get; set; }

        public string? Code { get; set; }

        public virtual ICollection<MenuRolePermission> MenuRolePermissions { get; set; } = new List<MenuRolePermission>();
    }
}
