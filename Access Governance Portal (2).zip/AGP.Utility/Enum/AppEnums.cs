﻿namespace AGP.Utility.Enum
{
    public class AppEnums
    {
    }

    public enum AuditActionTypeEnum
    {
        Create = 1,
        Update = 2,
        Delete = 3
    }

}
