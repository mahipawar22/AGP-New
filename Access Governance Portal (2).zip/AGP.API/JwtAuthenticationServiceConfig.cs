﻿
using AGP.Data.ViewModels;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace AGP.API
{
    public static class JwtAuthenticationServiceConfig
    {
        public static void AddJwtAuthenticationServices(this IServiceCollection services, IConfiguration configuration)
        {
            // Register the ConfigurationBuilder instance of AuthSettings
            var authSettings = configuration.GetSection("jwt");
            services.Configure<JwtOptions>(authSettings);

            var appSettings = authSettings.Get<JwtOptions>();

            var key = Encoding.ASCII.GetBytes(appSettings.secretKey);

            var signingKey = new SymmetricSecurityKey(key);

            var tokenValidationParams = new TokenValidationParameters()
            {
                ValidateIssuerSigningKey = true,

                ValidIssuer = configuration["jwt:issuer"].ToString(),
                ValidateIssuer = false,
                ValidateLifetime = true,
                ValidAudience = configuration["jwt:audience"].ToString(),
                ValidateAudience = false,
                RequireSignedTokens = true,
                IssuerSigningKey = signingKey
            };
        }

        public static async Task<UserSessionEntity> ValidateToken(MasterUserModel userModel,
               string audienceUri,
               string issuerUri,
               Guid applicationId,
               DateTime expires,
               string secretKey = null,
               bool isReAuthToken = false)
        {
            //string logPath = Path.Combine(Directory.GetCurrentDirectory(), "Logs", "API Account.txt");
          //  await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] ValidateToken\n");
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(secretKey);
                UserSessionEntity userEntity = new();
                userEntity.UserId = userModel.Id;
                userEntity.RoleId = userModel.RoleId;
                userEntity.RoleName = userModel.RoleName;
                userEntity.UserName = userModel.Name;
                userEntity.FirstName = userModel.EmpFname;
                userEntity.Email = userModel.Email;
                userEntity.ListPermission = userModel.ListPermission;
                userEntity.LastName = userModel.LastName;
                userEntity.EmployeeId = userModel.EmployeeId;
                userEntity.ReportingEmpids = ""; // userModel.ReportingEmpids;
                userEntity.IsTwoFactorEnabled = userModel.IsTwoFactorEnabled;

                //if(userEntity != null)
                    //await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] userEntity not null\n");

                var claims = new List<Claim>();

                claims.Add(new Claim("UserName", userEntity.UserName));
                claims.Add(new Claim("UserId", userEntity.UserId.ToString()));
                claims.Add(new Claim("RoleId", (userEntity.RoleId == null || userEntity.RoleId <= 0 ? String.Empty : userEntity.RoleId.ToString())));
                claims.Add(new Claim("UserEmail", userEntity.Email.ToString()));

                //await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] userEntity name\n" + userEntity.UserName);
                //await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] userEntity not null\n" + userEntity.UserId);
                //await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] userEntity not null\n" + userEntity.RoleId);

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(claims),
                    Expires = DateTime.Now.AddMinutes(300),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };

                var token = tokenHandler.CreateToken(tokenDescriptor);

                userEntity.UserToken = tokenHandler.WriteToken(token);
                userEntity.VallidTo = Convert.ToDateTime(tokenDescriptor.Expires);
                return userEntity;
            }
            catch (Exception ex)
            {
                //await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] ValidateToken Exception: {ex.Message}\n");
                throw new Exception("Token validation failed.", ex);
            }
        }
    }

    public class JwtOptions
    {
        public string secretKey { get; set; }
        public string issuer { get; set; }
        public bool validateLifetime { get; set; }
    }
}
