﻿using AGP.Core.Authorization;
using AGP.Core.IRepository;
using AGP.Core.Repository;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AGP.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        public UserController(IUserRepository userRepository) 
        {
            _userRepository = userRepository;
        }
        /// <summary>
        /// GetAll added by Dhanashree on Date 28-08-2025
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [CheckAccess("AGP.Users.View")]
        [HttpGet("getall")]
        public async Task<IActionResult> GetAll([FromQuery] GlobalSearchRequest model)
        {
            var apiResponse = await _userRepository.GetUsersAsync(model);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        /// <summary>
        /// GetById added by Dhanashree on Date 28-08-2025
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [CheckAccess("AGP.Users.View")]
        [HttpGet("getbyid")]
        public async Task<IActionResult> GetById(int id)
        {
            var apiResponse = await _userRepository.GetUserByIdAsync(id);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }        
        /// <summary>
        /// Assign Roles added by Dhanashree on Date 28-08-2025
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [CheckAccess("AGP.Users.Edit")]
        [HttpPost("update")]
        public async Task<IActionResult> UpdateRole([FromQuery] string employeeId,int roleId)
        {
            long modifiedBy = 1;

            var apiResponse = await _userRepository.UpdateRoleAsync(employeeId, roleId, modifiedBy);

            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        /// <summary>
        /// Deactivate User from Roles added by Dhanashree on Date 30-08-2025
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [CheckAccess("AGP.Users.Edit")]
        [HttpPost("deactivate")]
        public async Task<IActionResult> DeactivateUser([FromBody] DeactivateUserRequest employeeId)
        {
            var response = await _userRepository.DeactivateUserAsync(employeeId);

            if (!response.success)
                return NotFound(response);

            return Ok(response);
        }
        /// <summary>
        /// Add User Roles added by Dhanashree on Date 03-09-2025
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [CheckAccess("AGP.Users.Create")]
        [HttpPost("addusers")]
        public async Task<IActionResult> AddUsers([FromBody] AddUserRequest model)
        {
            var apiResponse = await _userRepository.AddUserAsync(model);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        /// <summary>
        /// GetEmployeeFromAscent added by Dhanashree on Date 03-09-2025
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [CheckAccess("AGP.Users.View")]
        [HttpGet("getemployeefromascent")]
        public async Task<IActionResult> GetEmployeeFromAscent([FromQuery] string employeeId = null, [FromQuery] string name = null)
        {
            var apiResponse = await _userRepository.GetEmployeeFromAscent(employeeId, name);

            if (apiResponse.success)
                return Ok(apiResponse);

            return BadRequest(apiResponse);
        }
    }
}
