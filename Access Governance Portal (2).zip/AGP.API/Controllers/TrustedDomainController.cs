﻿using AGP.Core.Authorization;
using AGP.Core.IRepository;
using AGP.Data.Entity;
using AGP.Data.ViewModels;
using Azure.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AGP.API.Controllers
{
   //  [AllowAnonymous]
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class TrustedDomainController : ControllerBase
    {
        private readonly ITrustedDomainRepository _trustedDomainRepository;

        public TrustedDomainController(ITrustedDomainRepository trustedDomainRepository)
        {
            _trustedDomainRepository = trustedDomainRepository; 
        }

        [CheckAccess("AGP.AccessRequest.Add")]
        [HttpPost("create")]
        public async Task<IActionResult> Create(List<TrustedDomainUpsertRequest> requests)
        {
            //$ from email address.
            var Useremail = User.FindFirst("UserEmail")?.Value;
            requests.Union(requests.Select(x => { x.CreatedByEmail = Useremail; return x; }));
            var apiResponse = await _trustedDomainRepository.BulkAddTrustedDomainRequest(requests, false);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpPost("add")]
        public async Task<IActionResult> Add(List<TrustedDomainUpsertRequest> requests)
        {
            //$ from email address.
            var Useremail = User.FindFirst("UserEmail")?.Value;
            requests.Union(requests.Select(x => { x.CreatedByEmail = Useremail; return x; }));
            var apiResponse = await _trustedDomainRepository.BulkAddTrustedDomainRequest(requests, true);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll([FromQuery] long code)
        
        {
            var apiResponse = await _trustedDomainRepository.GetTrustedDomainCreatedBy(code);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        
        [HttpGet("getfhrequestsbyid/{EmployeeId}")]
        public async Task<IActionResult> GetAllFHRequests([FromRoute] string EmployeeId)//[FromBody] string EmployeeId)
        {
           // var CreatedBy = User.FindFirst("UserId")?.Value;
            var apiResponse = await _trustedDomainRepository.GetTrustedDomainForFH(EmployeeId);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        [HttpGet("GetAllDraftTDRequests/{EmployeeId}")]
        public async Task<IActionResult> GetALlDraftTDRequests([FromRoute] string EmployeeId)
        {
            var apiResponse = await _trustedDomainRepository.GetALlDraftTDRequests(EmployeeId);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        /// <summary>
        /// update status from functional head
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>



        //  [HttpPost("UpdateStatusFromFH")]
        //public async Task<IActionResult> UpdateStatusForFH([FromBody] TrustedDomainStatusUpdateRequest request)
        //{
        //    var Useremail = User.FindFirst("UserEmail")?.Value;
        //    if (request == null || request.Id <= 0)
        //    {
        //        return BadRequest("Invalid request.");
        //    }

        //    var email = request.Email; 
        //    var justification = request.Justification ?? "No justification provided.";

        //    var apiResponse = await _trustedDomainRepository.UpdateStatusToApproved(request.Id,request.Justification,request.Email);

        //    return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        //}












        [HttpPost("UpdateStatusFromFH")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateStatusForFH([FromQuery] long id,string justification)
        {
           // var email = User.FindFirst("Email")?.Value;

            var apiResponse = await _trustedDomainRepository.UpdateStatusToApproved(id,justification);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        /// <summary>
        ///  completed the status for DLP Team. //$ Mahendra Refer this code.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
       // [HttpPost("UpdateStatusFromDLP")]
        [HttpPost("UpdateStatusFromDLP")]
        public async Task<IActionResult> ApproveFromDlp([FromQuery] long id, string justificaction)
        {

            var apiResponse = await _trustedDomainRepository.UpdateStatusToApprovedFromDlp(id,justificaction);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        /// <summary>
        /// to reject the status
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost("RejectStatus")]
        public async Task<IActionResult> RejectStatusForFH([FromQuery] long id,string justification)

        {
            var email = User.FindFirst("Email")?.Value;
            var apiResponse = await _trustedDomainRepository.UpdateStatusToRejectFromFH(id,justification);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }




        [HttpPost("RejectStatusFromDlp")]
        public async Task<IActionResult> RejectStatusFromDlp([FromQuery] long id, string justification)

        {
            var email = User.FindFirst("Email")?.Value;
            var apiResponse = await _trustedDomainRepository.UpdateStatusToRejectFromDlp(id, justification);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        /// <summary>
        /// to get Approved/rejected Requests
        /// </summary>
        /// <returns></returns>
        //[HttpGet("Approved")]
        [HttpGet("GetAllRequestsFromFH")]
        public async Task<IActionResult> GetAllRequestsFromFH()
        {
          //  var userIdClaim = User.FindFirst("UserId")?.Value;

            //int userId = 0;
            //if (!string.IsNullOrEmpty(userIdClaim) && int.TryParse(userIdClaim, out var parsedId))
            //{
            //    userId = parsedId;
            //}

            //string justification = "";
            var apiResponse = await _trustedDomainRepository.ApprovedTrustedDomainRequests();
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        /// <summary>
        /// To get Approved Requests only for IT team only Approved
        /// </summary>
        /// <returns></returns>
        [HttpGet("ApprovedForDlp")]
        //[HttpGet("GetAllRequestsForDlp")]
        public async Task<IActionResult> GetAllRequestsForDlp()

        {
            var apiResponse = await _trustedDomainRepository.ApprovedTrustedDomainRequestsForDlp();
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        /// <summary>
        /// To get All complted request from IT Team
        /// </summary>
        /// <returns></returns>

        [HttpGet("Completed")]
        //[HttpGet("GetAllCompltedRequestsFromDlp")]
        public async Task<IActionResult> GetAllCompltedRequestsFromDlp()

        {
            var apiResponse = await _trustedDomainRepository.CompletedTrustedDomainRequests();
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }


        [CheckAccess("AGP.TrustedDomain.Edit")]
        [HttpPost("update")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Update(TrustedDomainUpsertRequest request)
        {
            var Useremail = User.FindFirst("UserEmail")?.Value;
            request.CreatedByEmail = Useremail;
            var apiResponse = await _trustedDomainRepository.AddOrUpdateTrustedDomain(request);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [CheckAccess("AGP.TrustedDomain.Delete")]
        [HttpPost("delete/{id:long}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Delete(long id)
        {
            var apiResponse = await _trustedDomainRepository.DeleteTrustedDomain(id, 1);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

    
    }
}
