﻿using AGP.Core.Authorization;
using AGP.Core.IRepository;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.AccessRequest;
using AGP.Data.ViewModels.DlpIncident;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

[AllowAnonymous]
[ApiController]
[Route("api/[controller]")]
public class IncidentReportController : ControllerBase
{
    private readonly IIncidentRepostRopository _incidentRepository;
   

    public IncidentReportController(IIncidentRepostRopository incidentRepository)
    {
        _incidentRepository = incidentRepository;
    }

    /// <summary>
    /// Upload an incident report file.
    /// </summary>
    /// <param name="file">The file to upload.</param>
    /// <returns>Upload result with success status and message.</returns>
    [HttpPost("UploadFile")]
    //[Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ApiResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponseDto), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> UploadFile(IFormFile file)
    {
        if (file == null || file.Length == 0)
        {
            return BadRequest(new ApiResponseDto
            {
                Success = false,
                Message = "No file uploaded."
            });
        }

        var apiResponse = await _incidentRepository.UploadFile(file);

        // Map your repository result to a clean DTO
        var response = new ApiResponseDto
        {
            Success = apiResponse.success,
            Message = apiResponse.message
        };

        return apiResponse.success ? Ok(response) : BadRequest(response);
    }

    
    [HttpGet("GetIncidentReportForToday")]
    public async Task<IActionResult> GetIncidentReportByDate()
    {
        var apiResponse = await _incidentRepository.GetDlpReportByDate();
        return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
    }

    [HttpGet("GetAllIncidentReport")]
    public async Task<IActionResult> GetAllIncidentReport([FromQuery] string employeeId)
    {
        var apiResponse = await _incidentRepository.GetDlpReport(employeeId);
        return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
    }

    //for that user
    [HttpGet("GetAllIncidentReportForUser")]
    public async Task<IActionResult> GetAllIncidentReportForUser([FromQuery] string employeeId)
    {
        var apiResponse = await _incidentRepository.GetDlpReportforUser(employeeId);
        return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
    }



    [HttpPost("UpdateStatusIncidentReportFromFH")]
    public async Task<IActionResult> UpdateIncidentReportFromFH([FromBody] IncidentReportApprove request)
    {
        var apiResponse = await _incidentRepository.UpdateIncidentReportFromFH(request);
        return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
    }

    


}

public class ApiResponseDto
{
    public bool Success { get; set; }
    public string Message { get; set; }
}
