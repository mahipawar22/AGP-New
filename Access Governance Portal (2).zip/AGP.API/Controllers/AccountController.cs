﻿using AGP.Core.IRepository;
using AGP.Data.DBHelper;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace AGP.API.Controllers
{
    /// <summary>
    /// Controller created by Ashutosh B. Bodake
    /// All account related work.
    /// </summary>
    [AllowAnonymous]
    [ApiController]
    [Route("api/[controller]")]
    public class AccountController : ControllerBase
    {
        private readonly IAccountRepository _accountRepository;
        private readonly IConfiguration _configuration;
        public AccountController(IAccountRepository accountRepository,
                                 IConfiguration configuration)
        {
            _configuration = configuration;
            _accountRepository = accountRepository;
        }

        /// <summary>
        /// Method to login user.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel model)
        {
            //string logPath = Path.Combine(Directory.GetCurrentDirectory(), "Logs", "API.txt");
            //Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
            //await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] API Login Start\n");

            GlobalResponse apiResponse = new();
            try
            {
                UserSessionEntity userEntity = new();

                var userModel = await _accountRepository.Login(model);
                if (userModel != null)
                {

                    int expMinutes = Convert.ToInt32(_configuration["jwt:expiryMinutes"]);
                    userEntity = await JwtAuthenticationServiceConfig.ValidateToken(userModel, _configuration["jwt:audience"].ToString(),
                                 _configuration["jwt:issuer"].ToString(), Guid.NewGuid(),
                                 AppConstants.DateTime.AddMinutes(expMinutes),
                                 _configuration["jwt:secretKey"]);


                    CookieOptions options = new CookieOptions();

                    options.Expires = DateTime.Now.AddDays(7);
                    HttpContext.Response.Cookies.Append(AppConstants.AGPToken, userEntity.UserToken, options);

                    List<UserPermissionModel> dummy_userPermissionModels = new List<UserPermissionModel>();

                    PermissionHelper.UserPermissionList = userModel.ListPermission
                                                                   .Select(p=>p.Name)
                                                                   .Distinct()
                                                                   .Select(name => new UserPermissionModel { Name = name })
                                                                   .ToList<UserPermissionModel>(); 
                    apiResponse.success = true;
                    apiResponse.message = AppConstants.ActionSuccess;
                    apiResponse.data = userEntity;
                    return Ok(apiResponse);
                }
                else
                {
                    apiResponse.success = false;
                    apiResponse.errorMessage = string.Format(AppConstants.ErrorMessage, "");
                    return NotFound(apiResponse);
                }
            }
            catch (Exception ex)
            {
                apiResponse.success = false;
                apiResponse.errorMessage = string.Format(AppConstants.ErrorMessage, "");
                //await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] Exception\n" + ex.Message + "Inner Exception: " + ex.StackTrace);
                return NotFound(apiResponse);
            }
        }
    }
}
