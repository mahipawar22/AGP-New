﻿using AGP.Core.Authorization;
using AGP.Core.IRepository;
using AGP.Core.Repository;
using AGP.Data.DataContext;
using AGP.Data.Entity;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using Azure.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AGP.API.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class RolesController : ControllerBase
    {
        private readonly Core.IRepository.IRolesRepository service;        
        public RolesController(Core.IRepository.IRolesRepository _service)
        {
            service = _service;
        }

        /// <summary>
        /// GetAll added by Dhanashree on Date 21-08-2025
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [CheckAccess("AGP.Roles.Create")]
        [HttpPost("create")]
        public async Task<IActionResult> Create([FromBody] RolePermissionRequest request)
        {
            var apiResponse = await service.CreateOrUpdateAsync(request);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        /// <summary>
        /// GetAll added by Dhanashree on Date 21-08-2025
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [CheckAccess("AGP.Roles.Edit")]
        [HttpPost("edit")]
        public async Task<IActionResult> Update([FromBody] RolePermissionRequest request)
        {
            var apiResponse = await service.CreateOrUpdateAsync(request);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        /// <summary>
        /// GetAll added by Dhanashree on Date 21-08-2025
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [CheckAccess("AGP.Roles.View")]
        [HttpGet("getall")]
        public async Task<IActionResult> GetAll([FromQuery] GlobalSearchRequest model)
        {
            //Create and send success response
            var apiResponse = await service.GetAll(model);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [CheckAccess("AGP.Roles.View")]
        [HttpGet("getbyroleid")]
        public async Task<IActionResult> GetByRoleId(int RoleId)
        {
            var apiResponse = await service.GetByRoleId(RoleId);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [CheckAccess("AGP.Roles.Delete")]
        [HttpPost("delete")]
        public async Task<IActionResult> Delete([FromQuery] int roleId, [FromQuery] int permissionId)
        {
            var apiResponse = await service.RemovePermissions(roleId, permissionId);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        [CheckAccess("AGP.Roles.View")]
        [HttpGet("getroles")]
        public async Task<IActionResult> GetRolesAsync([FromQuery] GlobalSearchRequest model)
        {
            var apiResponse = await service.GetRolesAsync(model);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        [CheckAccess("AGP.Roles.View")]
        [HttpGet("getmenus")]
        public async Task<IActionResult> GetMenusAsync([FromQuery] GlobalSearchRequest model)
        {
            var apiResponse = await service.GetMenusAsync(model);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        [CheckAccess("AGP.Roles.View")]
        [HttpGet("getpermissions")]
        public async Task<IActionResult> GetPermissionsAsync([FromQuery] GlobalSearchRequest model)
        {
            var apiResponse = await service.GetPermissionsAsync(model);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
    }
}
