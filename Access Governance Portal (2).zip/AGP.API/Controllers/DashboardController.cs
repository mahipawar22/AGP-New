﻿using AGP.Core.Authorization;
using AGP.Core.IRepository;
using AGP.Core.Repository;
using AGP.Data.ViewModels.RequestReportModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AGP.API.Controllers
{
    //[AllowAnonymous]
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class DashboardController : ControllerBase
    {
        private readonly IDashboardRepository _dashboardRepository;
        private readonly IConfiguration _configuration;
        public DashboardController(IDashboardRepository dashboardRepository,
                                 IConfiguration configuration)
        {
            _configuration = configuration;
            _dashboardRepository = dashboardRepository;
        }

        [CheckAccess("AGP.Dashboard.View")]
        [HttpGet("getbycode/{EmployeeId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetAll([FromRoute] string? EmployeeId)
        {
            var apiResponse = await _dashboardRepository.GetRequestsByEmployeeId(EmployeeId);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpPost("getfhdashboard")]
        public async Task<IActionResult> GetFHDashboard([FromBody] string? EmployeeId)
        {
            if (EmployeeId == "IT TEAM")
                EmployeeId = string.Empty;

            if (EmployeeId == "FH")
            {
                EmployeeId = User.FindFirst("UserId")?.Value;
            }
            var apiResponse = await _dashboardRepository.GetRequestsByEmployeeId(EmployeeId);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
    }
}
