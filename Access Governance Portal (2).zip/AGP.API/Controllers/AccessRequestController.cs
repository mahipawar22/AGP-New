﻿using AGP.Core.Authorization;
using AGP.Core.IRepository;
using AGP.Core.Repository;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.AccessRequest;
using AGP.Data.ViewModels.BaseModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AGP.API.Controllers
{
    // [AllowAnonymous]
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class AccessRequestController : Controller
    {
        private readonly IAccessRequestRepository _trustedaccessRepository;

        public AccessRequestController(IAccessRequestRepository trustedaccessRepository)
        {
            _trustedaccessRepository = trustedaccessRepository;
        }

        [CheckAccess("AGP.AccessRequest.Add")]
        [HttpPost("add")]
        public async Task<IActionResult> Add(List<AccessRequestUpsertRequest> requests)
        {
            var Useremail = User.FindFirst("UserEmail")?.Value;
            requests.Union(requests.Select(x => { x.CreatedByEmail = Useremail; return x; }));
            var apiResponse = await _trustedaccessRepository.BulkAddAccessRequest(requests, true);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [CheckAccess("AGP.AccessRequest.Add")]
        [HttpPost("create")]
        public async Task<IActionResult> Create(List<AccessRequestUpsertRequest> requests)
        {
            var Useremail = User.FindFirst("UserEmail")?.Value;
            requests.Union(requests.Select(x => { x.CreatedByEmail = Useremail; return x; }));
            var apiResponse = await _trustedaccessRepository.BulkAddAccessRequest(requests, false);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [CheckAccess("AGP.AccessRequest.Edit")]
        [HttpPost("update")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Update(AccessRequestUpsertRequest request)
        {
            var Useremail = User.FindFirst("UserEmail")?.Value;
            request.CreatedByEmail = Useremail;
            var apiResponse = await _trustedaccessRepository.UpdateAccessRequest(request);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [CheckAccess("AGP.AccessRequest.Delete")]
        [HttpPost("delete/{id:long}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Delete(long id)
        {
            var CreatedBy = User.FindFirst("UserId")?.Value;
            var apiResponse = await _trustedaccessRepository.DeleteAccessRequest(id);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [CheckAccess("AGP.AccessRequest.View")]
        [HttpGet("getbycode")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetByCode([FromQuery] string Empcode)
        {
            long id = long.Parse(Empcode);
            var apiResponse = await _trustedaccessRepository.GetAccessRequestByCode(id);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll([FromQuery] long code)
        {
           // code = 1;
            var apiResponse = await _trustedaccessRepository.GetAccessRequestsCreatedBy(code);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        /// <summary>
        /// to get access categories 
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetAllCategories")]
        public async Task<IActionResult> GetCategories()
        {
            var apiResponse = await _trustedaccessRepository.GetCategories();
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        /// <summary>
        /// get locations
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <returns></returns>
        
        [HttpGet("GetAllLocations")]
        public async Task<IActionResult> GetLocations()
        {
            var apiResponse = await _trustedaccessRepository.GetLocations();
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        /// <summary>
        /// get All FH Requests
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <returns></returns>
        [HttpGet("getfhrequestsbyid/{EmployeeId}")]
        public async Task<IActionResult> GetAllFHRequests([FromRoute] string EmployeeId)//[FromBody] string EmployeeId)
        {
            var CreatedBy = User.FindFirst("UserId")?.Value;
            var apiResponse = await _trustedaccessRepository.GetAccessRequestForFH(EmployeeId);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpGet("GetAllDraftAccessRequests/{EmployeeId}")]
        public async Task<IActionResult> GetAllDraftRequests([FromRoute] string EmployeeId)
        {
            var apiResponse = await _trustedaccessRepository.GetAllDraftAccessRequests(EmployeeId);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpPost("UpdateStatusFromFH")]
        public async Task<IActionResult> UpdateStatusToApproveFH([FromQuery] long id, string justification)
        {
            var apiResponse = await _trustedaccessRepository.UpdateStatusToApproved (id,justification);

            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpPost("RejectStatus")]
        public async Task<IActionResult> Reject([FromQuery] long id, string justification)
        {
            var apiResponse = await _trustedaccessRepository.UpdateStatusToReject(id, justification);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        //to Update Status from IT Team 
        [HttpPost("UpdateStatusFromIT")]
        
        public async Task<IActionResult> UpdateStatusFromIT([FromQuery] long id, string justification)
        { 
            var apiResponse = await _trustedaccessRepository.UpdateStatusToApprovedFromIT(id, justification);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        [HttpPost("UpdateStatusToRejectFromIT")]
        public async Task<IActionResult> UpdateStatusToRejectFromIT([FromQuery] long id, string justification)
        {
            var apiResponse = await _trustedaccessRepository.UpdateStatusToRejectFromIT(id, justification);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }



        //To get Appproved or Rejected Requests for FH
        //[HttpGet("Approved")]
        [HttpGet("GetAllFHRequests")]
        public async Task<IActionResult> GetFHApprovedRequests()
        {
            var userIdClaim = User.FindFirst("UserId")?.Value;

            int userId = 0;
            if (!string.IsNullOrEmpty(userIdClaim) && int.TryParse(userIdClaim, out var parsedId))
            {
                userId = parsedId;
            }
            var apiResponse = await _trustedaccessRepository.ApprovedAccessRequests();
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
        //to get all approved requests from Functional haed only Approved from FH
        [HttpGet("GetAllApprovedForIT")]
        public async Task<IActionResult> GetApprovedRequestsForIT()

        {
            var apiResponse = await _trustedaccessRepository.ApprovedAccessRequestsForIT();
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }

        //Get All Completed requests for IT
        //[HttpGet("Completed")]
        [HttpGet("GetCompletedRequestsFromIT")]
        public async Task<IActionResult> GetCompletedRequestsFromIT()

        {
            var apiResponse = await _trustedaccessRepository.CompletedAccessRequests();
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }


        [HttpPost]
        public async Task<IActionResult> UploadFiles(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file selected.");

            var fileName = Path.GetFileNameWithoutExtension(file.FileName);
            var extension = Path.GetExtension(file.FileName);
            var uniqueName = $"{fileName}_{Guid.NewGuid():N}{extension}";

            // folder path
            var uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads/AccessDocs");
            Directory.CreateDirectory(uploadPath);

            // save file
            var filePath = Path.Combine(uploadPath, uniqueName);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            // relative path for frontend/browser
            var relativePath = $"/uploads/AccessDocs/{uniqueName}";

            return Ok(new { storedFileName = uniqueName, filePath = relativePath });
        }



    }
}
