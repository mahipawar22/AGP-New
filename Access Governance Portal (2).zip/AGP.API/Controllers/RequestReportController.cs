﻿using AGP.Core.Authorization;
using AGP.Core.IRepository;
using AGP.Data.ViewModels.RequestReportModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AGP.API.Controllers
{
    [AllowAnonymous]
    [ApiController]
    [Route("api/[controller]")]
    public class RequestReportController : ControllerBase
    {
        private readonly IRequestReportRepository _requestRepository;
        private readonly IConfiguration _configuration;
        public RequestReportController(IRequestReportRepository requestRepository,
                                 IConfiguration configuration)
        {
            _configuration = configuration;
            _requestRepository = requestRepository;
        }
        [CheckAccess("AGP.Request.View")]
        [HttpPost("getall")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetAll(EmployeeRequestFilter model)
        {
            var apiResponse = await _requestRepository.GetRequestsByEmployeeId(model);
            return apiResponse.success ? Ok(apiResponse) : BadRequest(apiResponse);
        }
    }
}
