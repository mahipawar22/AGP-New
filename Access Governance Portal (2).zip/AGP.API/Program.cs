﻿using AGP.API.Filter;
using AGP.Core.Authorization;
using AGP.Core.IRepository;
using AGP.Core.ModelMapper;
using AGP.Core.Repository;
using AGP.Core.Service;
using AGP.Data.BaseRepositories;
using AGP.Data.DataContext;
using AGP.Data.DBHelper;
using AGP.Data.UnitOfWork;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Converters;
using OfficeOpenXml;
using Serilog;
using System.Text;
using System.Text.Json.Serialization;

try
{
    var builder = WebApplication.CreateBuilder(args);

    ExcelPackage.License.SetNonCommercialPersonal("KSB");

    // ---------- Logging ----------
    var logger = new LoggerConfiguration()
        .ReadFrom.Configuration(builder.Configuration)
        .Enrich.FromLogContext()
        .CreateLogger();
    builder.Logging.ClearProviders();
    builder.Logging.AddSerilog(logger);

    builder.Services.AddControllers().AddNewtonsoftJson();
    builder.Services.AddControllers().AddJsonOptions(x =>
        x.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles);
    
    // default scheme to JWT Bearer
    builder.Services.AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    })
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = false,   // set true if you use issuer/audience in appsettings
            ValidateAudience = false, // set true if you use issuer/audience in appsettings
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(builder.Configuration["jwt:secretKey"])),

            // OPTIONAL if you configure Issuer/Audience
            ValidIssuer = builder.Configuration["jwt:Issuer"],
            ValidAudience = builder.Configuration["jwt:Audience"],

            // OPTIONAL: reduce clock skew if needed
            ClockSkew = TimeSpan.Zero
        };
    });
    

    DBConnection.AGP_ConStr = builder.Configuration["ConnectionString:AGPDB"];

    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen(c =>
    {
        // Enable file upload support
        c.OperationFilter<FileUploadOperationFilter>();
    });

    builder.Services.AddHttpContextAccessor();
    builder.Services.AddDistributedMemoryCache();
    builder.Services.AddSession(options =>
    {
        options.IdleTimeout = TimeSpan.FromSeconds(1800);
    });

    builder.Services.AddDbContext<AGPDBContext>(options =>
        options.UseSqlServer(builder.Configuration.GetConnectionString("AGPDB")));

    builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
    builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
    builder.Services.AddScoped<IMapperFactory, MapperFactory>();
    builder.Services.AddScoped<IHelper, Helper>();
    builder.Services.AddHttpContextAccessor();
    builder.Services.AddScoped<ICurrentUserService, CurrentUserService>();
    builder.Services.AddTransient<ITrustedDomainRepository, TrustedDomainRepository>();
    builder.Services.AddTransient<IAccessRequestRepository, AccessRequestRepository>();
    builder.Services.AddTransient<IRequestReportRepository, RequestReportRepository>();
    builder.Services.AddTransient<IDashboardRepository, DashboardRepository>();
    builder.Services.AddTransient<IAccountRepository, AccountRepository>();
    builder.Services.AddTransient<IRolesRepository, RolesRepository>();
    builder.Services.AddTransient<IUserRepository, UserRepository>();
    builder.Services.AddTransient<IIncidentRepostRopository, IncidentReportRepository>();

    builder.Services.AddCors(options =>
    {
        options.AddPolicy(name: "AGP",
            policy =>
            {
                policy.AllowAnyOrigin()
                      .AllowAnyHeader()
                      .AllowAnyMethod();
            });
    });

    builder.Services.AddControllers();

    var app = builder.Build();

    // Configure the HTTP request pipeline.
    app.UseSwagger(option =>
    {
        option.RouteTemplate = "api/agp/{documentname}/swagger.json";
    });

    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }

    app.UseSwaggerUI(option =>
    {
        option.SwaggerEndpoint("/AGP/api/agp/v1/swagger.json", "AGP API");
        option.RoutePrefix = "AGP/api/agp";
    });

    app.UseCors("AGP");

    app.UseHttpsRedirection();
    app.UseSession();
    app.UseAuthentication();
    app.UseAuthorization();
    app.UseMiddleware<JwtMiddleware>();
    app.MapControllers();

    app.Run();
}
catch (Exception ex)
{
    Log.Error(ex, "An error occurred while starting the application.");
    Log.Error(ex.Message, "An error occurred.");
    //string logPath = Path.Combine(Directory.GetCurrentDirectory(), "Logs", "API_Programdotcs.txt");
    //Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);

    //await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] Inner Exception message: " + ex.InnerException + "\n");
    //await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] message: " + ex.Message + "\n");
    //await System.IO.File.AppendAllTextAsync(logPath, $"[{DateTime.Now}] Stack Trace: " + ex.StackTrace + "\n");
    throw;
}




















