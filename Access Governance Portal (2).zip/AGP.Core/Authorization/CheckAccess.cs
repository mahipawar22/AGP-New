﻿using AGP.Data.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace AGP.Core.Authorization
{
    public sealed class CheckAccessAttribute : Attribute, IAuthorizationFilter
    {
        private readonly string filterParameter;
        public CheckAccessAttribute(string someFilterParameter)
        {
            filterParameter = someFilterParameter;
        }
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            try
            {
                //var userEntity = (UserSessionEntity)context.HttpContext.Items["User"];
                //if (userEntity != null)
                //{
                //    if (!PermissionHelper.UserPermissionList.Any(x => x.Name.Equals(filterParameter, StringComparison.OrdinalIgnoreCase)))
                //      context.Result = new ObjectResult("Forbidden") { StatusCode = 403 };
                //}
                //else
                //{
                //    context.Result = new UnauthorizedResult();
                //}
            }
            catch (Exception ex)
            {
                
            }
        }


    }
}
