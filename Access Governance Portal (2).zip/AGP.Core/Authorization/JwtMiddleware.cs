﻿using AGP.Core.Utility;
using AGP.Data.DBHelper;
using AGP.Data.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Text;

namespace AGP.Core.Authorization
{
    public class JwtMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _configuration;

        public JwtMiddleware(RequestDelegate next, IConfiguration Configuration)
        {
            _next = next;
            _configuration = Configuration;
        }

        public async Task Invoke(HttpContext context, IConfiguration Configuration)
        {
            string token = null;
            string permission = null;
            string auth = AppConstants.Authorization;


            if (context.Request.Cookies.Count > 0 && context.Request.Cookies.ContainsKey(AppConstants.AGPToken))
            {
                token = context.Request.Cookies[AppConstants.AGPToken];
            }
            if (context.Request.Cookies.Count > 0 && context.Request.Cookies.ContainsKey(AppConstants.AGPPermission))
            {
                permission = context.Request.Cookies[AppConstants.AGPPermission];
            }
            if (string.IsNullOrEmpty(token) && context.Request.Headers.TryGetValue(auth, out var authHeader))
            {
                var parts = authHeader.ToString().Split(' ');
                if (parts.Length == 2 && parts[0] == "Bearer")
                    token = parts[1];
            }
            /*else if (context.Request.Headers.ContainsKey(auth))
            {
                token = context.Request.Headers[auth].FirstOrDefault()?.Split(" ").Last();
            }*/

            if (token != null)
                attachUserToContext(context, token, permission);
            else
            {
                context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
            }
            await _next(context);
        }

        private void attachUserToContext(HttpContext context, string token, string permission)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_configuration["jwt:secretKey"]);
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;

                UserSessionEntity oUserLoggedInModel = new UserSessionEntity();
                oUserLoggedInModel = UtilityHelper.GetUserFromClaims(jwtToken.Claims);
                oUserLoggedInModel.Permissions = permission;
                // attach user to context on successful jwt validation               
                //if (oUserLoggedInModel != null)
                //{
                //    oUserLoggedInModel.ListPermission = oUserLoggedInModel.Permissions.Split(',').Select(x => new UserPermissionModel()
                //    {
                //        Name = x
                //    }).ToList();
                //    //Select(s =>Convert.ToString(s)).ToList();                   
                //}
                context.Items["User"] = oUserLoggedInModel;
            }
            catch (Exception ex)
            {
                // do nothing if jwt validation fails
                // user is not attached to context so request won't have access to secure routes
            }
        }
    }
}
