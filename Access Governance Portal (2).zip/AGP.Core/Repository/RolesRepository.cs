﻿using AGP.Core.IRepository;
using AGP.Core.ModelMapper;
using AGP.Core.Service;
using AGP.Data.BaseRepositories;
using AGP.Data.DataContext;
using AGP.Data.DBHelper;
using AGP.Data.Entity;
using AGP.Data.UnitOfWork;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using Azure.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.Repository
{
    public class RolesRepository : IRolesRepository
    {
        /// <summary>
        ///  Repository added by Dhanashree on Date 21-08-2025.
        ///  Repository used to handle all operations for Role Details.
        ///  </summary>
        private readonly AGPDBContext _context;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapperFactory _mapperFactory;
        private IRepository<Role> _repository;
        private readonly ILogger<RolesRepository> _logger;
        private readonly ICurrentUserService _currentUser;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="mapperFactory"></param>
        /// <param name="unitOfWork"></param>
        /// <param name="logger"></param>
        /// <param name="context"></param>
        public RolesRepository(AGPDBContext context, IMapperFactory mapperFactory, IUnitOfWork unitOfWork, ILogger<RolesRepository> logger,
                               ICurrentUserService currentUser)
        {
            _context = context;
            _mapperFactory = mapperFactory;
            _unitOfWork = unitOfWork;
            _repository = _unitOfWork.GetRepository<Role>();
            _logger = logger;
            _currentUser = currentUser;
        }

        /// <summary>
        /// GetAll method for fetching Role Details.
        /// Repository created by Dhanashree on Date 21-08-2025.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<GlobalResponse> GetAll(GlobalSearchRequest model)
        {
            string errMsg = "";
            string innrExMsg = "";
            GlobalResponse apiResponse = new();
            try
            {
                DbParameter[] dbParameters = Array.Empty<DbParameter>();

                // Call SP
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.SP_AGP_GetRolesWithPermissions,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters);
                
                var rolePermissions = new List<RolePermissionModel>();
                foreach (DataRow row in dt.Rows)
                {
                    rolePermissions.Add(new RolePermissionModel
                    {
                        MenuId = row["MenuId"] != DBNull.Value ? Convert.ToInt32(row["MenuId"]) : 0,
                        MenuName = row["MenuName"]?.ToString(),
                        RoleId = row["RoleId"] != DBNull.Value ? Convert.ToInt32(row["RoleId"]) : 0,
                        RoleName = row["RoleName"]?.ToString(),
                        PermissionId = row["PermissionId"] != DBNull.Value ? Convert.ToInt32(row["PermissionId"]) : (int?)null,
                        PermissionName = row["PermissionName"]?.ToString()
                    });
                }

                return new GlobalResponse
                {
                    message = rolePermissions.Count > 0 ? "Roles with that permissions." : "No records found.",
                    success = true,
                    data = rolePermissions
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetAllRolesWithPermissions", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }

        /// <summary>
        /// GetByRoleId method for fetching Role Details.
        /// Repository created by Dhanashree on Date 21-08-2025.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<GlobalResponse> GetByRoleId(int RoleId)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                DbParameter[] dbParameters =
                {
                    new DbParameter("RoleId", RoleId, SqlDbType.Int)
                };

                // Call SP
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.SP_AGP_GetPermissionsByRole, DBConnection.AGP_ConStr, 
                    CommandType.StoredProcedure, dbParameters);

                var permissions = new List<RolePermissionModel>();

                foreach (DataRow row in dt.Rows)
                {
                    permissions.Add(new RolePermissionModel
                    {
                        MenuId = row["MenuId"] != DBNull.Value ? Convert.ToInt32(row["MenuId"]) : 0,
                        MenuName = row["MenuName"]?.ToString(),
                        RoleId = row["RoleId"] != DBNull.Value ? Convert.ToInt32(row["RoleId"]) : 0,
                        RoleName = row["RoleName"]?.ToString(),
                        PermissionId = row["PermissionId"] != DBNull.Value ? Convert.ToInt32(row["PermissionId"]) : (int?)null,
                        PermissionName = row["PermissionName"]?.ToString()
                    });
                }

                return new GlobalResponse
                {
                    message = permissions.Any() ? "Permissions fetched successfully." : "No permissions found for this role.",
                    success = true,
                    data = permissions
                };
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                _logger.LogError(AppConstants.ErrorMessage, "GetByRoleId", ex);

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }
        /// <summary>
        /// This CreateOrUpdateAsync method is used Create and update record for Role Details.
        /// Repository created by Dhanashree on Date 21-08-2025.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<GlobalResponse> CreateOrUpdateAsync(RolePermissionRequest request)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                var dbParameter = new DbParameter[]
                {
                    new DbParameter("Id", request.Id ?? (object)DBNull.Value, SqlDbType.Int),
                    new DbParameter("MenuId", request.MenuId, SqlDbType.Int), 
                    new DbParameter("RoleId", request.RoleId, SqlDbType.Int),
                    new DbParameter("PermissionId", request.PermissionId, SqlDbType.Int),
                    new DbParameter("UserId", Convert.ToInt32(request.UserId), SqlDbType.BigInt)
                };

                object result = AGPDBHelper.ExecuteScalar(
                    ProcedureDictionary.SP_AGP_CreateOrUpdateRolePermission,
                    DBConnection.AGP_ConStr, CommandType.StoredProcedure, dbParameter);
                

                return new GlobalResponse
                {
                    data = null,
                    message = AppConstants.ActionSuccess,
                    success = true
                };
            }
            catch (Exception ex)
            {
                _logger.LogInformation(AppConstants.ErrorMessage, "CreateOrUpdateAsync");
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse()
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }
        /// <summary>
        /// This RemovePermissions method is used Delete records for Role Details.
        /// Repository created by Dhanashree on Date 21-08-2025.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<GlobalResponse> RemovePermissions(int roleId, int permissionId)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                var dbParameter = new DbParameter[]
                {
                    new DbParameter("RoleId", roleId, SqlDbType.Int),
                    new DbParameter("PermissionId", permissionId, SqlDbType.Int)
                };

                int rowsAffected = AGPDBHelper.ExecuteNonQuery(
                    ProcedureDictionary.SP_AGP_RemoveRolePermission,
                    DBConnection.AGP_ConStr, CommandType.StoredProcedure, dbParameter);

                if (rowsAffected > 0)
                {
                    return new GlobalResponse
                    {
                        data = rowsAffected,
                        message = "Role permission removed successfully.",
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        errorMessage = "No records were deleted. RoleId/PermissionId may not exist.",
                        success = false
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in RemoveRolePermissionAsync");
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse()
                {
                    errorMessage = $"Exception occured while removing role permission: {ex?.Message}",
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }
        public async Task<GlobalResponse> GetMenusAsync(GlobalSearchRequest model)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                var menus = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.SP_AGP_GetMenus,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure);

                return new GlobalResponse
                {
                    data = menus,
                    message = AppConstants.ActionSuccess,
                    success = true
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetMenusAsync");
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }

        public async Task<GlobalResponse> GetRolesAsync(GlobalSearchRequest model)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                var roles = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.SP_AGP_GetRoles,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure);

                return new GlobalResponse
                {
                    data = roles,
                    message = AppConstants.ActionSuccess,
                    success = true
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetRolesAsync");
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }
        public async Task<GlobalResponse> GetPermissionsAsync(GlobalSearchRequest model)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                var permissions = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.SP_AGP_GetPermissions,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure);

                return new GlobalResponse
                {
                    data = permissions,
                    message = AppConstants.ActionSuccess,
                    success = true
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetPermissionsAsync");
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }

    }
}

