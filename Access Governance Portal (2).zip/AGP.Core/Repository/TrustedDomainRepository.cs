﻿using AGP.Core.IRepository;
using AGP.Core.ModelMapper;
using AGP.Core.Service;
using AGP.Data.BaseRepositories;
using AGP.Data.DataContext;
using AGP.Data.DBHelper;
using AGP.Data.Entity;
using AGP.Data.UnitOfWork;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.AccessRequest;
using AGP.Data.ViewModels.BaseModels;
using AGP.Data.ViewModels.TrustedDomain;
using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using OfficeOpenXml;
using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;




namespace AGP.Core.Repository
{
    /// <summary>
    /// Initial Base structure of Backend created by Ashutosh B.
    /// </summary>
    public class TrustedDomainRepository : ITrustedDomainRepository
    {
        private readonly AGPDBContext _dbContext;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IHelper _helper;
        private readonly IMapperFactory _mapperFactory;
        private IRepository<TrustedDomain> _trustedDomain;
        private readonly ILogger<TrustedDomainRepository> _logger;
        private readonly IConfiguration _configuration;
        private readonly ICurrentUserService _currentUser;

        public TrustedDomainRepository(IMapperFactory mapperFactory, IUnitOfWork unitOfWork,
            ILogger<TrustedDomainRepository> logger,
            //IAuditLogRepository auditLogRepository,
            AGPDBContext dbContext,
            IHelper helper,
            IConfiguration configuration,
            ICurrentUserService currentUser)
        {
            _mapperFactory = mapperFactory;
            _unitOfWork = unitOfWork;
            _dbContext = dbContext;
            _helper = helper;
            _trustedDomain = _unitOfWork.GetRepository<TrustedDomain>();
            _logger = logger;
            _configuration = configuration;
            _currentUser = currentUser;
        }

        public async Task<GlobalResponse> AddOrUpdateTrustedDomain(TrustedDomainUpsertRequest request)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {

                if (request.Id != 0)
                {
                    return await UpdateTrustedDomain(request);
                }

                long newId = 0;
                DbParameter[] dbParameter =
                {
            new DbParameter("DomainCompanyName",  request.DomainCompanyName, SqlDbType.NVarChar),
            new DbParameter("RelationshipWithKSB",  request.RelationshipWithKSB, SqlDbType.NVarChar),
            new DbParameter("DomainOrEmail",    request.DomainOrEmail, SqlDbType.NVarChar),
            new DbParameter("WhitelistType",  request.WhitelistType.ToString(), SqlDbType.NVarChar),
            new DbParameter("StartDate",   request.StartDate ?? (object)DBNull.Value, SqlDbType.Date),
            new DbParameter("EndDate",   request.EndDate ?? (object)DBNull.Value, SqlDbType.Date),
            new DbParameter("Justification",   request.Justification, SqlDbType.NVarChar),
            new DbParameter("CreatedBy", request.CreatedBy, SqlDbType.BigInt),
            new DbParameter("ModifiedBy", request.ModifiedBy, SqlDbType.BigInt),
            new DbParameter("CreatedByEmail",   request.CreatedByEmail, SqlDbType.NVarChar)
                };

                object result = AGPDBHelper.ExecuteScalar(ProcedureDictionary.sp_AGP_TrustedDomain_Create, DBConnection.AGP_ConStr, CommandType.StoredProcedure, dbParameter);
                if (result != null)
                {
                    newId = Convert.ToInt64(result);
                }

                _logger.LogInformation(AppConstants.successMessage, "AddOrUpdateTrustedDomain");

                return new GlobalResponse
                {
                    data = await GetTrustedDomainByCode(newId),
                    message = AppConstants.ActionSuccess,
                    success = true,
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "AddOrUpdateTrustedDomain", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse()
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(request);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "AddOrUpdateTrustedDomain", reqresMsg, errMsg, innrExMsg);
            }
        }




        public async Task<GlobalResponse> BulkAddTrustedDomainRequest(List<TrustedDomainUpsertRequest> requests, bool Add=false)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                var dataTable = ToAccessRequestDataTable(requests);

                var dbParameter = new DbParameter[]
                {
                    new DbParameter("TrustedDomainRequests", dataTable, SqlDbType.Structured),
                    new DbParameter("IsAdd", Add, SqlDbType.Bit)
                };

                object result = AGPDBHelper.ExecuteScalar(
                    ProcedureDictionary.sp_AGP_TrustedDomain_BulkInsert_Insert,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameter
                );

                return new GlobalResponse
                {
                    data = null,
                    message = AppConstants.ActionSuccess,
                    success = Convert.ToInt32(result) == 1
                };
            }
            catch (Exception ex)
            {
                _logger.LogInformation(AppConstants.ErrorMessage, "BulkAddAccessRequest");
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse()
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(requests);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "BulkAddTrustedDomainRequest", reqresMsg, errMsg, innrExMsg);
            }
        }


        public async Task<GlobalResponse> UpdateTrustedDomain(TrustedDomainUpsertRequest request)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                if (request.Id <= 0)
                {
                    return new GlobalResponse()
                    {
                        errorMessage = "Invalid ID for update.",
                        success = false
                    };
                }

                DbParameter[] dbParameter =
                {
                  new DbParameter("Id", request.Id, SqlDbType.BigInt),
                new DbParameter("DomainCompanyName",  request.DomainCompanyName, SqlDbType.NVarChar),
                new DbParameter("RelationshipWithKSB",  request.RelationshipWithKSB, SqlDbType.NVarChar),
                new DbParameter("DomainOrEmail",    request.DomainOrEmail, SqlDbType.NVarChar),
                 new DbParameter("WhitelistType",  request.WhitelistType.ToString(), SqlDbType.NVarChar),
                new DbParameter("StartDate",   request.StartDate ?? (object)DBNull.Value, SqlDbType.Date),
                 new DbParameter("EndDate",   request.EndDate ?? (object)DBNull.Value, SqlDbType.Date),
                new DbParameter("Justification",   request.Justification, SqlDbType.NVarChar),
                 new DbParameter("ModifiedBy", request.ModifiedBy, SqlDbType.BigInt)
                };

                int rowsAffected = AGPDBHelper.ExecuteNonQuery(ProcedureDictionary.sp_AGP_TrustedDomain_Update, DBConnection.AGP_ConStr, CommandType.StoredProcedure, dbParameter);

                if (rowsAffected > 0)
                {
                    _logger.LogInformation(AppConstants.successMessage, "UpdateTrustedDomain");

                    return new GlobalResponse
                    {
                        data = await GetTrustedDomainByCode(request.Id),
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        errorMessage = "No records were updated.",
                        success = false
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateTrustedDomain", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse()
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(request);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "UpdateTrustedDomain", reqresMsg, errMsg, innrExMsg);
            }
        }
        /// <summary>
        /// get all trusted domain
        /// </summary>
        /// <param name="createdBy"></param>
        /// <returns></returns>

        public async Task<GlobalResponse> GetTrustedDomainCreatedBy(long createdBy)
        {

            string errMsg = "";
            string innrExMsg = "";
            try
            {
                if (createdBy <= 0)
                {
                    return new GlobalResponse
                    {
                        errorMessage = "Invalid CreatedBy ID.",
                        success = false
                    };
                }

                DbParameter[] dbParameters =
                {
             new DbParameter("CreatedBy", createdBy, SqlDbType.BigInt)
         };

                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_TrustedDomain_GetByCreatedBy,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    // Map to your DTO or response model
                    var trustedDomains = dt.AsEnumerable()
                                           .Select(row => new TrustedDomainUpsertRequest
                                           {
                                               Id = Convert.ToInt64(row["Id"]),
                                               DomainCompanyName = row["DomainCompanyName"]?.ToString(),
                                               DomainOrEmail = row["DomainOrEmail"]?.ToString(),
                                               RelationshipWithKSB = row["RelationshipWithKSB"]?.ToString(),
                                               StartDate = row["StartDate"] as DateTime?,
                                               EndDate = row["EndDate"] as DateTime?,
                                               WhitelistType = row["WhitelistType"]?.ToString(),
                                               Justification = row["Justification"]?.ToString(),
                                               CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                               Status = row["Status"].ToString(),

                                           }).ToList();

                    return new GlobalResponse
                    {
                        data = trustedDomains,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No data found for the provided CreatedBy.",
                        success = true,
                        data = new List<TrustedDomainUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetTrustedDomainsByCreatedBy", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(createdBy);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "GetTrustedDomainCreatedBy", reqresMsg, errMsg, innrExMsg);
            }
        }

        public async Task<GlobalResponse> GetTrustedDomainForFH(string EmployeeIds)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                DbParameter[] dbParameters =
                {
                 new DbParameter("EmployeeId", EmployeeIds, SqlDbType.VarChar)
                };
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_FH_TrustedDomain_GetByEmpId,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    // Map to your DTO or response model
                    var trustedDomains = dt.AsEnumerable()
                                           .Select(row => new TrustedDomainUpsertRequest
                                           {
                                               Id = Convert.ToInt64(row["Id"]),
                                               DomainCompanyName = row["DomainCompanyName"]?.ToString(),
                                               DomainOrEmail = row["DomainOrEmail"]?.ToString(),
                                               RelationshipWithKSB = row["RelationshipWithKSB"]?.ToString(),
                                               StartDate = row["StartDate"] as DateTime?,
                                               EndDate = row["EndDate"] as DateTime?,
                                               WhitelistType = row["WhitelistType"]?.ToString(),
                                               Justification = row["Justification"]?.ToString(),
                                               CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                               Status = row["Status"].ToString(),
                                               CreatedByEmail = row["CreatedByEmail"].ToString(),
                                           }).ToList();

                    return new GlobalResponse
                    {
                        data = trustedDomains,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No data found for the provided CreatedBy.",
                        success = true,
                        data = new List<TrustedDomainUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetTrustedDomainsByCreatedBy", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(EmployeeIds);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "GetTrustedDomainForFH", reqresMsg, errMsg, innrExMsg);
            }
        }



        public async Task<GlobalResponse> GetALlDraftTDRequests(string EmployeeIds)
        {
            try
            {
                DbParameter[] dbParameters =
                {
                 new DbParameter("EmployeeId", EmployeeIds, SqlDbType.VarChar)
                };
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_AllTrustedDomain_Draft,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    // Map to your DTO or response model
                    var trustedDomains = dt.AsEnumerable()
                                           .Select(row => new TrustedDomainUpsertRequest
                                           {
                                               Id = Convert.ToInt64(row["Id"]),
                                               DomainCompanyName = row["DomainCompanyName"]?.ToString(),
                                               DomainOrEmail = row["DomainOrEmail"]?.ToString(),
                                               RelationshipWithKSB = row["RelationshipWithKSB"]?.ToString(),
                                               StartDate = row["StartDate"] as DateTime?,
                                               EndDate = row["EndDate"] as DateTime?,
                                               WhitelistType = row["WhitelistType"]?.ToString(),
                                               SerialNumber = row["SerialNumber"]?.ToString(),
                                               Justification = row["Justification"]?.ToString(),
                                               //SerialNumber = row["SerialNumber"]?.ToString(),
                                               CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                               Status = row["Status"].ToString(),
                                           }).ToList();

                    return new GlobalResponse
                    {
                        data = trustedDomains,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No data found for the provided CreatedBy.",
                        success = true,
                        data = new List<TrustedDomainUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetTrustedDomainsByCreatedBy", ex);

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
        }

        /// <summary>
        /// to Get all Approved/Rejected Requets of Trusted domain 
        /// </summary>
        /// <returns></returns>
        public async Task<GlobalResponse> ApprovedTrustedDomainRequests()
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                DbParameter[] dbParameters = Array.Empty<DbParameter>();

                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_TrustedDomain_Get_Approved,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    var approvedDomains = dt.AsEnumerable()
                                            .Where(row => row["Status"] != DBNull.Value &&
                                                         (row["Status"].ToString().Equals("Approved", StringComparison.OrdinalIgnoreCase) ||
                                                          row["Status"].ToString().Equals("Rejected", StringComparison.OrdinalIgnoreCase)))
                                            .Select(row => new TrustedDomainUpsertRequest
                                            {
                                                Id = Convert.ToInt64(row["Id"]),
                                                DomainCompanyName = row["DomainCompanyName"]?.ToString(),
                                                SerialNumber = row["SerialNumber"]?.ToString(),
                                                DomainOrEmail = row["DomainOrEmail"]?.ToString(),
                                                RelationshipWithKSB = row["RelationshipWithKSB"]?.ToString(),
                                                StartDate = row["StartDate"] as DateTime?,
                                                EndDate = row["EndDate"] as DateTime?,
                                                WhitelistType = row["WhitelistType"]?.ToString(),
                                                Justification = row["Justification"]?.ToString(),
                                                CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                                Status = row["Status"]?.ToString(),
                                                Remark = row["Remark"]?.ToString(),
                                                SubmissionDate = row["SubmissionDate"] as DateTime?,
                                                FHActionDate = row["FHActionDate"] as DateTime?,
                                                ModifiedBy = row["ModifiedBy"] != DBNull.Value ? Convert.ToInt64(row["ModifiedBy"]) : null,
                                                AccessDurationInDays = row["AccessDurationInDays"] != DBNull.Value ? Convert.ToInt32(row["AccessDurationInDays"]) : null
                                            })
                                            .ToList();

                    return new GlobalResponse
                    {
                        data = approvedDomains,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No approved trusted domains found.",
                        success = true,
                        data = new List<TrustedDomainUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "ApprovedTrustedDomainRequests", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "ApprovedTrustedDomainRequests", reqresMsg, errMsg, innrExMsg);
            }
        }

        /// working method on 29/09
        //public async Task<GlobalResponse> ApprovedTrustedDomainRequests(int id)
        //{
        //    string errMsg = "";
        //    string innrExMsg = "";
        //    try
        //    {
        //        DbParameter[] dbParameters = Array.Empty<DbParameter>();

        //        DataTable dt = AGPDBHelper.ExecuteDataTable(
        //            ProcedureDictionary.sp_AGP_TrustedDomain_Get_Approved,
        //            DBConnection.AGP_ConStr,
        //            CommandType.StoredProcedure,
        //            dbParameters
        //        );

        //        if (dt != null && dt.Rows.Count > 0)
        //        {
        //            var approvedDomains = dt.AsEnumerable()
        //                                    .Where(row => row["Status"] != DBNull.Value &&
        //                                                 (row["Status"].ToString().Equals("Approved", StringComparison.OrdinalIgnoreCase) ||
        //                                                  row["Status"].ToString().Equals("Rejected", StringComparison.OrdinalIgnoreCase)))
        //                                    .Select(row => new TrustedDomainUpsertRequest
        //                                    {
        //                                        Id = Convert.ToInt64(row["Id"]),
        //                                        DomainCompanyName = row["DomainCompanyName"]?.ToString(),
        //                                        SerialNumber = row["SerialNumber"]?.ToString(),
        //                                        DomainOrEmail = row["DomainOrEmail"]?.ToString(),
        //                                        RelationshipWithKSB = row["RelationshipWithKSB"]?.ToString(),
        //                                        StartDate = row["StartDate"] as DateTime?,
        //                                        EndDate = row["EndDate"] as DateTime?,
        //                                        WhitelistType = row["WhitelistType"]?.ToString(),
        //                                        Justification = row["Justification"]?.ToString(),
        //                                        CreatedBy = Convert.ToInt64(row["CreatedBy"]),
        //                                        Status = row["Status"]?.ToString(),
        //                                        Remark = row["Remark"]?.ToString(),
        //                                        SubmissionDate = row["SubmissionDate"] as DateTime?,
        //                                        FHActionDate = row["FHActionDate"] as DateTime?,
        //                                        ModifiedBy = row["ModifiedBy"] != DBNull.Value ? Convert.ToInt64(row["ModifiedBy"]) : null,
        //                                        AccessDurationInDays = row["AccessDurationInDays"] != DBNull.Value ? Convert.ToInt32(row["AccessDurationInDays"]) : null
        //                                    })
        //                                    .ToList();

        //            return new GlobalResponse
        //            {
        //                data = approvedDomains,
        //                message = AppConstants.ActionSuccess,
        //                success = true
        //            };
        //        }
        //        else
        //        {
        //            return new GlobalResponse
        //            {
        //                message = "No approved trusted domains found.",
        //                success = true,
        //                data = new List<TrustedDomainUpsertRequest>()
        //            };
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(AppConstants.ErrorMessage, "ApprovedTrustedDomainRequests", ex);
        //        errMsg = ex.Message;
        //        innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
        //        return new GlobalResponse
        //        {
        //            errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
        //            success = false
        //        };
        //    }
        //    finally
        //    {
        //        string reqresMsg = JsonConvert.SerializeObject("");
        //        AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "ApprovedTrustedDomainRequests", reqresMsg, errMsg, innrExMsg);
        //    }
        //}



        /// <summary>
        ///  to get all Approved Requests for IT Team only Approved
        /// </summary>
        /// <returns></returns>
        public async Task<GlobalResponse> ApprovedTrustedDomainRequestsForDlp()
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                DbParameter[] dbParameters = Array.Empty<DbParameter>();

                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_TrustedDomain_Get_Approved,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    var approvedDomains = dt.AsEnumerable()
                                            .Where(row => row["Status"] != DBNull.Value &&
                                                         (row["Status"].ToString().Equals("Approved", StringComparison.OrdinalIgnoreCase)))
                                            .Select(row => new TrustedDomainUpsertRequest
                                            {
                                                Id = Convert.ToInt64(row["Id"]),
                                                DomainCompanyName = row["DomainCompanyName"]?.ToString(),
                                                DomainOrEmail = row["DomainOrEmail"]?.ToString(),
                                                RelationshipWithKSB = row["RelationshipWithKSB"]?.ToString(),
                                                StartDate = row["StartDate"] as DateTime?,
                                                EndDate = row["EndDate"] as DateTime?,
                                                WhitelistType = row["WhitelistType"]?.ToString(),
                                                Justification = row["Justification"]?.ToString(),
                                                CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                                Status = row["Status"]?.ToString(),
                                                Remark = row["Remark"]?.ToString(),
                                                // RequestDate = row["RequestDate"] as DateTime? ?? DateTime.UtcNow,
                                                //ApprovedDate = row["ApprovedDate"] as DateTime?,
                                                ModifiedBy = row["ModifiedBy"] != DBNull.Value ? Convert.ToInt64(row["ModifiedBy"]) : null,
                                                AccessDurationInDays = row["AccessDurationInDays"] != DBNull.Value ? Convert.ToInt32(row["AccessDurationInDays"]) : null
                                            })
                                            .ToList();

                    return new GlobalResponse
                    {
                        data = approvedDomains,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No approved trusted domains found.",
                        success = true,
                        data = new List<TrustedDomainUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "ApprovedTrustedDomainRequests", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "ApprovedTrustedDomainRequestsForDlp", reqresMsg, errMsg, innrExMsg);
            }
        }




        //public async Task<GlobalResponse> ApprovedTrustedDomainRequestsForIT()
        //{
        //    try
        //    {
        //        DbParameter[] dbParameters = Array.Empty<DbParameter>();

        //        DataTable dt = AGPDBHelper.ExecuteDataTable(
        //            ProcedureDictionary.sp_AGP_TrustedDomain_Get_Approved_ForIT,
        //            DBConnection.AGP_ConStr,
        //            CommandType.StoredProcedure,
        //            dbParameters
        //        );

        //        if (dt != null && dt.Rows.Count > 0)
        //        {
        //            var approvedDomains = dt.AsEnumerable()
        //                                    .Where(row => row["Status"] != DBNull.Value &&
        //                                                 (row["Status"].ToString().Equals("Approved", StringComparison.OrdinalIgnoreCase)))
        //                                    .Select(row => new TrustedDomainUpsertRequest
        //                                    {
        //                                        Id = Convert.ToInt64(row["Id"]),
        //                                        DomainCompanyName = row["DomainCompanyName"]?.ToString(),
        //                                        DomainOrEmail = row["DomainOrEmail"]?.ToString(),
        //                                        RelationshipWithKSB = row["RelationshipWithKSB"]?.ToString(),
        //                                        StartDate = row["StartDate"] as DateTime?,
        //                                        EndDate = row["EndDate"] as DateTime?,
        //                                        WhitelistType = row["WhitelistType"]?.ToString(),
        //                                        Justification = row["Justification"]?.ToString(),
        //                                        CreatedBy = (long)(row["CreatedBy"] != DBNull.Value ? Convert.ToInt64(row["CreatedBy"]) : (long?)null),
        //                                        Status = row["Status"]?.ToString(),
        //                                        Remark = row["Remark"]?.ToString(),
        //                                        // RequestDate = row["RequestDate"] as DateTime? ?? DateTime.UtcNow,
        //                                        //ApprovedDate = row["ApprovedDate"] as DateTime?,
        //                                        ModifiedBy = row["ModifiedBy"] != DBNull.Value ? Convert.ToInt64(row["ModifiedBy"]) : null,
        //                                        AccessDurationInDays = row["AccessDurationInDays"] != DBNull.Value ? Convert.ToInt32(row["AccessDurationInDays"]) : null
        //                                    })
        //                                    .ToList();

        //            return new GlobalResponse
        //            {
        //                data = approvedDomains,
        //                message = AppConstants.ActionSuccess,
        //                success = true
        //            };
        //        }
        //        else
        //        {
        //            return new GlobalResponse
        //            {
        //                message = "No approved trusted domains found.",
        //                success = true,
        //                data = new List<TrustedDomainUpsertRequest>()
        //            };
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(AppConstants.ErrorMessage, "ApprovedTrustedDomainRequests", ex);

        //        return new GlobalResponse
        //        {
        //            errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
        //            success = false
        //        };
        //    }
        //}


        // To get All Complted Request for IT
        public async Task<GlobalResponse> CompletedTrustedDomainRequests()
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                DbParameter[] dbParameters = Array.Empty<DbParameter>();

                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_TrustedDomains_Get_Completed,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    var trustedDomains = dt.AsEnumerable()
                                           .Select(row => new TrustedDomainUpsertRequest
                                           {
                                               Id = Convert.ToInt64(row["Id"]),
                                               DomainCompanyName = row["DomainCompanyName"]?.ToString(),
                                               DomainOrEmail = row["DomainOrEmail"]?.ToString(),
                                               RelationshipWithKSB = row["RelationshipWithKSB"]?.ToString(),
                                               StartDate = row["StartDate"] as DateTime?,
                                               EndDate = row["EndDate"] as DateTime?,
                                               WhitelistType = row["WhitelistType"]?.ToString(),
                                               Justification = row["Justification"]?.ToString(),
                                               CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                               Status = row["Status"]?.ToString(),
                                               DLPStatus = row["DLPStatus"]?.ToString(),
                                               Remark = row["Remark"]?.ToString(),
                                               ModifiedBy = row["ModifiedBy"] != DBNull.Value ? Convert.ToInt64(row["ModifiedBy"]) : (long?)null,
                                               AccessDurationInDays = row["AccessDurationInDays"] != DBNull.Value ? Convert.ToInt32(row["AccessDurationInDays"]) : (int?)null
                                           })
                                           .ToList();

                    return new GlobalResponse
                    {
                        data = trustedDomains,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No Completed or Rejected trusted domains found.",
                        success = true,
                        data = new List<TrustedDomainUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "CompletedTrustedDomainRequests", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException?.Message ?? "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("");
                AuditLogRepository.SaveAuditLog(
                    _currentUser.GetUserId().ToString(),
                    AppConstants.TrustedDomain,
                    "CompletedTrustedDomainRequests",
                    reqresMsg,
                    errMsg,
                    innrExMsg
                );
            }
        }



        //working method on 19/09
        //public async Task<GlobalResponse> CompletedTrustedDomainRequests()
        //{
        //    string errMsg = "";
        //    string innrExMsg = "";
        //    try
        //    {
        //        DbParameter[] dbParameters = Array.Empty<DbParameter>();

        //        DataTable dt = AGPDBHelper.ExecuteDataTable(
        //            ProcedureDictionary.sp_AGP_TrustedDomains_Get_Completed,
        //            DBConnection.AGP_ConStr,
        //            CommandType.StoredProcedure,
        //            dbParameters
        //        );

        //        if (dt != null && dt.Rows.Count > 0)
        //        {
        //            var approvedDomains = dt.AsEnumerable()
        //                                    .Where(row => row["Status"] != DBNull.Value &&
        //                                                 (row["Status"].ToString().Equals("Completed", StringComparison.OrdinalIgnoreCase)))
        //                                    .Select(row => new TrustedDomainUpsertRequest
        //                                    {
        //                                        Id = Convert.ToInt64(row["Id"]),
        //                                        DomainCompanyName = row["DomainCompanyName"]?.ToString(),
        //                                        DomainOrEmail = row["DomainOrEmail"]?.ToString(),
        //                                        RelationshipWithKSB = row["RelationshipWithKSB"]?.ToString(),
        //                                        StartDate = row["StartDate"] as DateTime?,
        //                                        EndDate = row["EndDate"] as DateTime?,
        //                                        WhitelistType = row["WhitelistType"]?.ToString(),
        //                                        Justification = row["Justification"]?.ToString(),
        //                                        CreatedBy = Convert.ToInt64(row["CreatedBy"]),
        //                                        Status = row["Status"]?.ToString(),
        //                                        Remark = row["Remark"]?.ToString(),
        //                                        // RequestDate = row["RequestDate"] as DateTime? ?? DateTime.UtcNow,
        //                                        //ApprovedDate = row["ApprovedDate"] as DateTime?,
        //                                        ModifiedBy = row["ModifiedBy"] != DBNull.Value ? Convert.ToInt64(row["ModifiedBy"]) : null,
        //                                        AccessDurationInDays = row["AccessDurationInDays"] != DBNull.Value ? Convert.ToInt32(row["AccessDurationInDays"]) : null
        //                                    })
        //                                    .ToList();

        //            return new GlobalResponse
        //            {
        //                data = approvedDomains,
        //                message = AppConstants.ActionSuccess,
        //                success = true
        //            };
        //        }
        //        else
        //        {
        //            return new GlobalResponse
        //            {
        //                message = "No Completed trusted domains found.",
        //                success = true,
        //                data = new List<TrustedDomainUpsertRequest>()
        //            };
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(AppConstants.ErrorMessage, "CompletedTrustedDomainRequests", ex);
        //        errMsg = ex.Message;
        //        innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
        //        return new GlobalResponse
        //        {
        //            errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
        //            success = false
        //        };
        //    }
        //    finally
        //    {
        //        string reqresMsg = JsonConvert.SerializeObject("");
        //        AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "CompletedTrustedDomainRequests", reqresMsg, errMsg, innrExMsg);
        //    }
        //}




        public async Task<GlobalResponse> DeleteTrustedDomain(long id, long modifiedBy = 1)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                if (id <= 0 || modifiedBy <= 0)
                {
                    return new GlobalResponse
                    {
                        errorMessage = "Invalid ID or user for deletion.",
                        success = false
                    };
                }

                DbParameter[] dbParameters =
                {
            new DbParameter("Id", id, SqlDbType.BigInt),
            new DbParameter("ModifiedBy",  modifiedBy, SqlDbType.BigInt) // or use "DeletedBy" if that's the parameter name in the SP
        };

                int rowsAffected = AGPDBHelper.ExecuteNonQuery(
                    ProcedureDictionary.sp_AGP_TrustedDomain_Delete,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters
                );

                if (rowsAffected > 0)
                {
                    _logger.LogInformation("Trusted domain deleted successfully. ID: {Id}", id);

                    return new GlobalResponse
                    {
                        message = "Trusted domain deleted successfully.",
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        errorMessage = "No records were deleted. ID may not exist.",
                        success = false
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception occurred while deleting trusted domain. ID: {Id}", id);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = $"Exception occurred while performing the action, error: {ex?.Message}",
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(id);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "DeleteTrustedDomain", reqresMsg, errMsg, innrExMsg);
            }
        }

        public async Task<GlobalResponse> GetTrustedDomainByCode(long code)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                DbParameter[] parameters =
                {
                           new DbParameter("Id", code, SqlDbType.BigInt)
                };

                var result = AGPDBHelper.ExecuteDataTable("sp_AGP_TrustedDomain_GetById", DBConnection.AGP_ConStr, CommandType.StoredProcedure, parameters);

                return new GlobalResponse
                {
                    data = result,
                    success = true,
                    message = "Fetched successfully"
                };
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    success = false,
                    errorMessage = $"Failed to fetch trusted domain. Error: {ex.Message}"
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(code);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "GetTrustedDomainByCode", reqresMsg, errMsg, innrExMsg);
            }
        }

        public Task<GlobalResponse> SearchTrustedDomainPagewise(GlobalSearchRequest model)
        {
            throw new NotImplementedException();
        }

        public Task<GlobalResponse> DeleteTrustedDomain(long id, int ModifiedBy)
        {
            throw new NotImplementedException();
        }

        private DataTable ToAccessRequestDataTable(List<TrustedDomainUpsertRequest> requests)
        {
            var table = new DataTable();
            table.Columns.Add("DomainCompanyName", typeof(string));
            table.Columns.Add("RelationshipWithKSB", typeof(string));
            table.Columns.Add("DomainOrEmail", typeof(string));
            table.Columns.Add("WhitelistType", typeof(string));
            table.Columns.Add("StartDate", typeof(DateTime));
            table.Columns.Add("EndDate", typeof(DateTime));
            table.Columns.Add("AccessDurationInDays", typeof(int));
            table.Columns.Add("Justification", typeof(string));
            table.Columns.Add("Status", typeof(string));
            table.Columns.Add("CreatedBy", typeof(long));
            table.Columns.Add("SerialNumber", typeof(string));
            table.Columns.Add("CreatedByEmail", typeof(string));

            foreach (var r in requests)
            {
                table.Rows.Add(
                    r.DomainCompanyName,
                    r.RelationshipWithKSB,
                    r.DomainOrEmail,
                    r.WhitelistType,
                    r.StartDate,
                    r.EndDate,
                    r.AccessDurationInDays ?? (object)DBNull.Value,
                    r.Justification,
                    r.Status,
                    r.CreatedBy,
                    r.SerialNumber
                );
            }

            return table;
        }

        

        public async Task<GlobalResponse> UpdateStatusToRejectFromFH(long id, string justification)
        {
            try
            {
                if (id <= 0)
                {
                    return new GlobalResponse
                    {
                        success = false,
                        errorMessage = "Invalid TrustedDomain ID."
                    };
                }
                //string toEmail ="mahendrapawar939@gmail.com" ;
                //string fromEmail ="mahendrapawar939@gmail.com" ;
                //string toEmail = _configuration["Smtp:toEmail"];
                //string fromEmail = _configuration["Smtp:fromEmail"];
                //EmailService.SendEmail(_configuration, fromEmail, toEmail);

                using (var conn = new SqlConnection(DBConnection.AGP_ConStr))
                using (var cmd = new SqlCommand("sp_AGP_TrustedDomain_BulkUpdateStatus", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Id", id.ToString());
                    cmd.Parameters.AddWithValue("@NewStatus", "REJECTED");
                    cmd.Parameters.AddWithValue("@Remark", justification ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@ModifiedBy", DBNull.Value);
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();

                    return rowsAffected > 0
                        ? new GlobalResponse { success = true, message = "Status updated to 'Rejected' successfully." }
                        : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToReject", ex);

                return new GlobalResponse
                {
                    success = false,
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                };
            }
        }



        //reject status from DLP
        public async Task<GlobalResponse> UpdateStatusToRejectFromDlp(long id, string justification)
        {
            try
            {
                if (id <= 0)
                {
                    return new GlobalResponse
                    {
                        success = false,
                        errorMessage = "Invalid TrustedDomain ID."
                    };
                }
                //string toEmail ="mahendrapawar939@gmail.com" ;
                //string fromEmail ="mahendrapawar939@gmail.com" ;
                //string toEmail = _configuration["Smtp:toEmail"];
                //string fromEmail = _configuration["Smtp:fromEmail"];
                //EmailService.SendEmail(_configuration, fromEmail, toEmail);

                using (var conn = new SqlConnection(DBConnection.AGP_ConStr))
                using (var cmd = new SqlCommand("sp_AGP_TrustedDomain_BulkUpdateDLPStatus", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Id", id.ToString());
                    cmd.Parameters.AddWithValue("@NewDLPStatus", "REJECTED");
                    cmd.Parameters.AddWithValue("@Justification", justification ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@ModifiedBy", DBNull.Value);
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();

                    return rowsAffected > 0
                        ? new GlobalResponse { success = true, message = "Status updated to 'Rejected' successfully." }
                        : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToReject", ex);

                return new GlobalResponse
                {
                    success = false,
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                };
            }
        }

      


        public async Task<GlobalResponse> UpdateStatusToApproved(long id, string justification)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                if (id <= 0)
                {
                    return new GlobalResponse
                    {
                        success = false,
                        errorMessage = "Invalid TrustedDomain ID."
                    };
                }

                string toEmail = _configuration["Smtp:toEmail"];
                string fromEmail = _configuration["Smtp:fromEmail"];
                // string fromEmail = User.FindFirst("UserEmail")?.Value; ;
                //EmailService.SendEmail(_configuration, fromEmail, toEmail);

                using (var conn = new SqlConnection(DBConnection.AGP_ConStr))

                using (var cmd = new SqlCommand("sp_AGP_TrustedDomain_BulkUpdateStatus", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Id", id.ToString());
                    cmd.Parameters.AddWithValue("@NewStatus", "APPROVED");
                    cmd.Parameters.AddWithValue("@Remark", justification ?? (object)DBNull.Value);
                    // cmd.Parameters.AddWithValue("@CreatedByEmail", Email ?? (object)DBNull.Value);

                    //cmd.Parameters.AddWithValue("@ModifiedBy", modifiedBy ?? (object)DBNull.Value);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();

                    return rowsAffected > 0
                        ? new GlobalResponse { success = true, message = "Status updated to 'Approved' successfully." }
                        : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToApproved", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    success = false,
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(id);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "UpdateStatusToApproved", reqresMsg, errMsg, innrExMsg);
            }
        }





        public async Task<GlobalResponse> UpdateStatusToApprovedFromDlp(long id, string justification)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                if (id <= 0)
                {
                    return new GlobalResponse
                    {
                        success = false,
                        errorMessage = "Invalid TrustedDomain ID."
                    };
                }

               // string toEmail = _configuration["Smtp:toEmail"];
                //string fromEmail = _configuration["Smtp:fromEmail"];
                // string fromEmail = User.FindFirst("UserEmail")?.Value; ;
              //  EmailService.SendEmail(_configuration, fromEmail, toEmail);

                using (var conn = new SqlConnection(DBConnection.AGP_ConStr))

                using (var cmd = new SqlCommand("sp_AGP_TrustedDomain_BulkUpdateStatus_FromDlp", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Id", id.ToString());
                    cmd.Parameters.AddWithValue("@NewStatus", "COMPLETED");
                    cmd.Parameters.AddWithValue("@Justification", justification ?? (object)DBNull.Value);
                    // cmd.Parameters.AddWithValue("@CreatedByEmail", Email ?? (object)DBNull.Value);

                    //cmd.Parameters.AddWithValue("@ModifiedBy", modifiedBy ?? (object)DBNull.Value);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();

                    return rowsAffected > 0
                        ? new GlobalResponse { success = true, message = "Status updated to 'Completed' successfully." }
                        : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToApproved", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    success = false,
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(id);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "UpdateStatusToApproved", reqresMsg, errMsg, innrExMsg);
            }
        }

       

        /*
          // method to update status as reject
          public async Task<GlobalResponse> UpdateStatusToReject(long id)
          {
              try
              {
                  if (id <= 0)
                  {
                      return new GlobalResponse
                      {
                          success = false,
                          errorMessage = "Invalid TrustedDomain ID."
                      };
                  }

                  using (var conn = new SqlConnection(DBConnection.AGP_ConStr))
                  using (var cmd = new SqlCommand("sp_AGP_TrustedDomain_BulkUpdateStatus", conn))
                  {
                      cmd.CommandType = CommandType.StoredProcedure;

                      cmd.Parameters.AddWithValue("@Id", id.ToString());
                      cmd.Parameters.AddWithValue("@NewStatus", "Rejected");
                      cmd.Parameters.AddWithValue("@Justification","Rejected for Demo");
                      cmd.Parameters.AddWithValue("@ModifiedBy", DBNull.Value);
                      conn.Open();
                      int rowsAffected = cmd.ExecuteNonQuery();
                      conn.Close();

                     return rowsAffected > 0
                         ? new GlobalResponse { success = true, message = "Status updated to 'Rejected' successfully." }
                         : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
                 }
             }
             catch (Exception ex)
             {
                 _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToRejeceted", ex);
                 errMsg = ex.Message;
                 innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                 return new GlobalResponse
                 {
                     success = false,
                     errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                 };
             }
             finally
             {
                 string reqresMsg = JsonConvert.SerializeObject(id);
                 AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.TrustedDomain, "UpdateStatusToReject", reqresMsg, errMsg, innrExMsg);
             }
         }
                      return rowsAffected > 0
                          ? new GlobalResponse { success = true, message = "Status updated to 'Rejected' successfully." }
                          : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
                  }
              }
              catch (Exception ex)
              {
                  _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToRejeceted", ex);

                  return new GlobalResponse
                  {
                      success = false,
                      errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                  };
              }
          }
         */





        /*   public async Task<GlobalResponse> UpdateStatusToApproved(long id)
           {
               try
               {
                   if (id <= 0)
                   {
                       return new GlobalResponse
                       {
                           success = false,
                           errorMessage = "Invalid TrustedDomain ID."
                       };
                   }

                   // Use string for Id, because SP expects a comma-separated string
                   var parameters = new DbParameter[]
                   {
               new DbParameter("Id", id.ToString(), SqlDbType.VarChar),                 // SP expects VARCHAR
               new DbParameter("NewStatus", "Approved", SqlDbType.NVarChar),
               new DbParameter("Justification", "Approved for demo", SqlDbType.NVarChar),
               new DbParameter("ModifiedBy", DBNull.Value, SqlDbType.BigInt)            // Optional
                   };

                   int rowsAffected = AGPDBHelper.ExecuteNonQuery(
                       ProcedureDictionary.sp_AGP_TrustedDomain_BulkUpdateStatus,
                       DBConnection.AGP_ConStr,
                       CommandType.StoredProcedure,
                       parameters
                   );

                   return rowsAffected > 0
                       ? new GlobalResponse { success = true, message = "Status updated to 'Approved' successfully." }
                       : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
               }
               catch (Exception ex)
               {
                   _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToApproved", ex);

                   return new GlobalResponse
                   {
                       success = false,
                       errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                   };
               }
           }*/




    }
}

