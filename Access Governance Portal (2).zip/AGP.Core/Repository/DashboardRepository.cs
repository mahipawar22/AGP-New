﻿using AGP.Core.IRepository;
using AGP.Core.ModelMapper;
using AGP.Core.Service;
using AGP.Data.BaseRepositories;
using AGP.Data.DataContext;
using AGP.Data.DBHelper;
using AGP.Data.Entity;
using AGP.Data.UnitOfWork;
using AGP.Data.ViewModels.BaseModels;
using AGP.Data.ViewModels.RequestReportModel;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.Repository
{
    public class DashboardRepository : IDashboardRepository
    {
        private readonly AGPDBContext _dbContext;
        private readonly IHelper _helper;
        private readonly ILogger<DashboardRepository> _logger;
        private readonly ICurrentUserService _currentUser;

        public DashboardRepository(AGPDBContext dbContext,
                                   IHelper helper,
                                   ILogger<DashboardRepository> logger,
                                   ICurrentUserService currentUser)
        {
            _dbContext = dbContext;
            _helper = helper;
            _logger = logger;
            _currentUser = currentUser;
        }


        public async Task<GlobalResponse> GetRequestsByEmployeeId(string EmployeeId)
        {
            EmployeeRequestModel empReq = new();
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                DbParameter[] parameters =
                {
                  new DbParameter(AppConstants.EmployeeId , EmployeeId, SqlDbType.NVarChar)
                };

                var result = AGPDBHelper.ExecuteSingleMappedReader<RequestReportSummaryModel>(
                             ProcedureDictionary.sp_AGP_User_Dashbaord_GetById,
                             DBConnection.AGP_ConStr,
                             CommandType.StoredProcedure,
                             parameters);

                if (result == null)
                {
                    return new GlobalResponse
                    {
                        message = AppConstants.NoRecordFound,
                        success = true
                    };
                }

                return new GlobalResponse
                {
                    data = result,
                    message = AppConstants.ActionSuccess,
                    success = true
                };

            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetRequestByEmployeeId", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    message = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(EmployeeId);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Dashboard, "Dashboard", reqresMsg, errMsg, innrExMsg);
            }
        }

    }
}

