﻿using AGP.Core.IRepository;
using AGP.Core.ModelMapper;
using AGP.Core.Service;
using AGP.Data.BaseRepositories;
using AGP.Data.DataContext;
using AGP.Data.DBHelper;
using AGP.Data.Entity;
using AGP.Data.UnitOfWork;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IHelper _helper;
        private readonly IMapperFactory _mapperFactory;
        private IRepository<User> _userRepository;
        private readonly ILogger<UserRepository> _logger;
        private readonly IConfiguration _configuration;
        private readonly ICurrentUserService _currentUser;

        public UserRepository(IMapperFactory mapperFactory, IUnitOfWork unitOfWork,
            ILogger<UserRepository> logger,IHelper helper, IConfiguration configuration, ICurrentUserService currentUser)
        {
            _mapperFactory = mapperFactory;
            _unitOfWork = unitOfWork;
            _helper = helper;
            _userRepository = _unitOfWork.GetRepository<User>();
            _logger = logger;
            _configuration = configuration;
            _currentUser = currentUser;
        }

        /// <summary>
        /// GetAll method for fetching Users Details.
        /// Repository created by Dhanashree on Date 28-08-2025.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<GlobalResponse> GetUsersAsync(GlobalSearchRequest model)
        {
            string errMsg = "";
            string innrExMsg = "";
            GlobalResponse apiResponse = new();
            try
            {
                DbParameter[] dbParameters = Array.Empty<DbParameter>();

                // Call SP
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.SP_AGP_Users_GetAll,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters);

                var users = new List<UserModel>();
                foreach (DataRow row in dt.Rows)
                {
                    users.Add(new UserModel
                    {
                        Id = row["Id"] != DBNull.Value ? Convert.ToInt32(row["Id"]) : 0,
                        EmployeeId = row["EmployeeId"]?.ToString(),
                        Name = row["Name"]?.ToString(),
                        Email = row["Email"]?.ToString(),
                        DepartmentName = row["DepartmentId"]?.ToString(),
                        RoleId = row["RoleId"] != DBNull.Value ? Convert.ToInt32(row["RoleId"]) : 0,
                        IsActive = row["IsActive"] != DBNull.Value ? Convert.ToBoolean(row["IsActive"]) : false,
                        CreatedBy = row["CreatedBy"] != DBNull.Value ? Convert.ToInt64(row["CreatedBy"]) : 0,
                        CreatedOn = row["CreatedOn"] != DBNull.Value ? Convert.ToDateTime(row["CreatedOn"]) : DateTime.MinValue,
                        ModifiedBy = row["ModifiedBy"] != DBNull.Value ? Convert.ToInt64(row["ModifiedBy"]) : 0,
                        ModifiedOn = row["ModifiedOn"] != DBNull.Value ? Convert.ToDateTime(row["ModifiedOn"]) : DateTime.MinValue,
                        Password = row["Password"]?.ToString(),
                        IsDeleted = row["IsDeleted"] != DBNull.Value ? Convert.ToBoolean(row["IsDeleted"]) : false,
                        FirstName = row["FirstName"]?.ToString(),
                        LastName = row["LastName"]?.ToString()
                    });
                }

                return new GlobalResponse
                {
                    message = users.Count > 0 ? "All the Users." : "No records found.",
                    success = true,
                    data = users
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetUsersAsync", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(model);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.User, "GetUsersAsync", reqresMsg, errMsg, innrExMsg);
            }
        }
        /// <summary>
        /// GetUserByIdAsync method for fetching User Details.
        /// Repository created by Dhanashree on Date 21-08-2025.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<GlobalResponse> GetUserByIdAsync(int Id)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                DbParameter[] dbParameters =
                {
                    new DbParameter("Id", Id, SqlDbType.BigInt)
                };

                // Call SP
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.SP_AGP_Users_GetById, DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure, dbParameters);

                var user = new List<UserModel>();

                foreach (DataRow row in dt.Rows)
                {
                    user.Add(new UserModel
                    {
                        Id = row["Id"] != DBNull.Value ? Convert.ToInt32(row["Id"]) : 0,
                        EmployeeId = row["EmployeeId"]?.ToString(),
                        Name = row["Name"]?.ToString(),
                        Email = row["Email"]?.ToString(),
                        DepartmentName = row["DepartmentId"]?.ToString(),
                        RoleId = row["RoleId"] != DBNull.Value ? Convert.ToInt32(row["RoleId"]) : 0,
                        IsActive = row["IsActive"] != DBNull.Value ? Convert.ToBoolean(row["IsActive"]) : false,
                        CreatedBy = row["CreatedBy"] != DBNull.Value ? Convert.ToInt64(row["CreatedBy"]) : 0,
                        CreatedOn = row["CreatedOn"] != DBNull.Value ? Convert.ToDateTime(row["CreatedOn"]) : DateTime.MinValue,
                        ModifiedBy = row["ModifiedBy"] != DBNull.Value ? Convert.ToInt64(row["ModifiedBy"]) : 0,
                        ModifiedOn = row["ModifiedOn"] != DBNull.Value ? Convert.ToDateTime(row["ModifiedOn"]) : DateTime.MinValue,
                        Password = row["Password"]?.ToString(),
                        IsDeleted = row["IsDeleted"] != DBNull.Value ? Convert.ToBoolean(row["IsDeleted"]) : false,
                        FirstName = row["FirstName"]?.ToString(),
                        LastName = row["LastName"]?.ToString()
                    });
                }

                return new GlobalResponse
                {
                    message = user.Any() ? "User fetched successfully." : "No User found for this id.",
                    success = true,
                    data = user
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetUserById", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(Id);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.User, "GetUsersAsync", reqresMsg, errMsg, innrExMsg);
            }
        }

        /// <summary>
        /// UpdateRoleAsync method for Modified roles to Users..
        /// Repository created by Dhanashree on Date 28-08-2025.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<GlobalResponse> UpdateRoleAsync(string employeeId, int roleId, long modifiedBy)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                DbParameter[] dbParameters =
                {
                     new DbParameter("EmployeeId", employeeId, SqlDbType.VarChar),
                     new DbParameter("RoleId", roleId, SqlDbType.Int),
                     new DbParameter("ModifiedBy", modifiedBy, SqlDbType.BigInt)
                };

                int rowsAffected = AGPDBHelper.ExecuteNonQuery(
                    ProcedureDictionary.SP_AGP_Users_AssignRole, DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure, dbParameters);

                return new GlobalResponse
                {
                    success = rowsAffected > 0,
                    message = rowsAffected > 0 
                             ? "Role modified successfully." 
                             : "No user found with given EmployeeId.",
                    data = new { EmployeeId = employeeId, RoleId = roleId }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "Update Role", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("employeeid: " + employeeId + "roleid" + roleId);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.User, "UpdateRoleAsync", reqresMsg, errMsg, innrExMsg);
            }
        }
        /// <summary>
        /// DeactivateUserAsync method for Deactivate User from roles.
        /// Repository created by Dhanashree on Date 30-08-2025.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<GlobalResponse> DeactivateUserAsync(DeactivateUserRequest request)
        {
            try
            {
                DbParameter[] dbParameters =
                {
                  new DbParameter("EmployeeId", request.EmployeeId, SqlDbType.VarChar) 
                };

                int rowsAffected = AGPDBHelper.ExecuteNonQuery(
                    ProcedureDictionary.SP_AGP_DeactivatedUser,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters);

                return new GlobalResponse
                {
                    success = rowsAffected > 0,
                    message = rowsAffected > 0
                             ? "User deactivated successfully."
                             : "No user found with given EmployeeId.",
                    data = new { EmployeeId = request.EmployeeId, IsActive = false } 
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "Deactivate User", ex);

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
        }
        /// <summary>
        /// AddUsersAsync method for Adding Users from AscentEmpMaster.
        /// Repository created by Dhanashree on Date 03-09-2025.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<GlobalResponse> AddUserAsync(AddUserRequest model)
        {
            try
            {
                var deptId = 0;
                if (!string.IsNullOrEmpty(model.Department))
                {
                    int.TryParse(model.Department, out deptId); // convert string to int
                }
                DbParameter[] dbParameters =
                {
                   new DbParameter("EmployeeId", model.EmployeeId, SqlDbType.VarChar),
                   new DbParameter("Name", model.Name, SqlDbType.VarChar),
                   new DbParameter("RoleId", model.RoleId ?? (object)DBNull.Value, SqlDbType.Int),
                   new DbParameter("Department", deptId, SqlDbType.Int),
                   new DbParameter("UserId", Convert.ToInt32(model.CreatedBy), SqlDbType.BigInt)
                };

                // Since SP returns Success, Message, use ExecuteDataTable
                var dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.SP_AGP_AddUsersFromAscentMaster,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters);

                if (dt.Rows.Count > 0)
                {
                    var row = dt.Rows[0];

                    return new GlobalResponse
                    {
                        success = Convert.ToInt32(row["Success"]) == 1,
                        message = row["Message"]?.ToString(),
                        data = new { EmployeeId = model.EmployeeId }
                    };
                }

                return new GlobalResponse
                {
                    success = false,
                    message = "No response returned from database."
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "Adding User", ex);

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
        }
        /// <summary>
        /// GetEmployeeFromAscent method for Getting Users from AscentEmpMaster.
        /// Repository created by Dhanashree on Date 03-09-2025.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<GlobalResponse> GetEmployeeFromAscent(string employeeId, string name)
        {
            try
            {
                var parameters = new[]
                {
                    new DbParameter("EmployeeId", string.IsNullOrEmpty(employeeId) ? (object)DBNull.Value :employeeId,            SqlDbType.VarChar),
                    new DbParameter("Name", string.IsNullOrEmpty(name) ? (object)DBNull.Value : name, SqlDbType.VarChar)
                };

                // Execute stored procedure
                var dt = await Task.Run(() =>
                    AGPDBHelper.ExecuteDataTable(
                        ProcedureDictionary.SP_AGP_GetEmployeeFromAscent,
                        DBConnection.AGP_ConStr,
                        CommandType.StoredProcedure,
                        parameters
                    )
                );

                if (dt.Rows.Count > 0)
                {
                    var employees = dt.AsEnumerable().Select(row => new EmployeeResponse
                    {
                        EmployeeId = row.Table.Columns.Contains("EmployeeId") ? row["EmployeeId"].ToString() : null,
                        Name = row.Table.Columns.Contains("Name") ? row["Name"].ToString() : null,
                        Department = row.Table.Columns.Contains("Department") ? row["Department"].ToString() : null
                    }).ToList();

                    return new GlobalResponse
                    {
                        success = true,
                        message = "Employees fetched successfully.",
                        data = employees   // return list instead of single employee
                    };
                }

                return new GlobalResponse
                {
                    success = false,
                    message = "No employee found in Ascent.",
                    data = null
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetEmployeeFromAscent", ex);

                return new GlobalResponse
                {
                    success = false,
                    message = "Error while fetching employee from Ascent.",
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                };
            }
        }

    }
}
