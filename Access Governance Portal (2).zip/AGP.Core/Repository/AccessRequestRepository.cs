﻿using AGP.Core.IRepository;
using AGP.Core.ModelMapper;
using AGP.Core.Service;
using AGP.Data.BaseRepositories;
using AGP.Data.DataContext;
using AGP.Data.DBHelper;
using AGP.Data.Entity;
using AGP.Data.UnitOfWork;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.AccessRequest;
using AGP.Data.ViewModels.BaseModels;
using Azure.Core;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.Repository
{
    public class AccessRequestRepository : IAccessRequestRepository
    {
        private readonly AGPDBContext _dbContext;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IHelper _helper;
        private readonly IMapperFactory _mapperFactory;
        private IRepository<AccessRequest> _trustedDomain;
        private readonly ILogger<AccessRequestRepository> _logger;
        private readonly ICurrentUserService _currentUser;

        public AccessRequestRepository(IMapperFactory mapperFactory, IUnitOfWork unitOfWork,
            ILogger<AccessRequestRepository> logger,
            //IAuditLogRepository auditLogRepository,
            AGPDBContext dbContext,
            IHelper helper,
            ICurrentUserService currentUser
            )
        {
            _mapperFactory = mapperFactory;
            _unitOfWork = unitOfWork;
            _dbContext = dbContext;
            _helper = helper;
            _trustedDomain = _unitOfWork.GetRepository<AccessRequest>();
            _logger = logger;
            _currentUser = currentUser;
        }
        public async Task<GlobalResponse> AddAccessRequest(AccessRequestUpsertRequest request)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                long newId = 0;
                DbParameter[] dbParameter =
                {
                 new DbParameter("EmployeeName", request.EmployeeName, SqlDbType.NVarChar),
                 new DbParameter("EmployeeId", request.EmployeeId, SqlDbType.NVarChar),
                 new DbParameter("DepartmentName", request.DepartmentName, SqlDbType.NVarChar),
                 new DbParameter("Location", request.Location, SqlDbType.NVarChar),
                 new DbParameter("AccessCategoryId", request.AccessCategoryId, SqlDbType.Int),
                 new DbParameter("Reason", request.Reason, SqlDbType.NVarChar),
                 new DbParameter("IsTemporaryAccess", request.IsTemporaryAccess, SqlDbType.Bit),
                 new DbParameter("AccessDurationInDays", request.AccessDurationInDays ?? (object)DBNull.Value, SqlDbType.Int),
                 new DbParameter("CreatedBy", request.CreatedBy, SqlDbType.BigInt),
                 new DbParameter("AccessFromDate", request.AccessFromDate, SqlDbType.DateTime),
                 new DbParameter("AccessToDate", request.AccessToDate, SqlDbType.DateTime)
                };

                object result = AGPDBHelper.ExecuteScalar(ProcedureDictionary.sp_AGP_AccessRequest_Create, DBConnection.AGP_ConStr, CommandType.StoredProcedure, dbParameter);
                if (result != null)
                {
                    newId = Convert.ToInt32(result);
                }

                _logger.LogInformation(AppConstants.successMessage, "AddOrUpdateDictionary");

                return new GlobalResponse
                {
                    data = await GetAccessRequestByCode(newId),
                    message = AppConstants.ActionSuccess,
                    success = true,
                };
            }
            catch (Exception ex)
            {
                _logger.LogInformation(AppConstants.ErrorMessage, "AddOrUpdateDictionary");
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse()
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(request);
                AuditLogRepository.SaveAuditLog(request.CreatedBy.ToString(), AppConstants.AccessRequest, "AddAccessRequest", reqresMsg, errMsg, innrExMsg);
            }
        }

        public async Task<GlobalResponse> BulkAddAccessRequest(List<AccessRequestUpsertRequest> requests, bool Add = false)
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                var dataTable = ToAccessRequestDataTable(requests);

                var dbParameter = new DbParameter[]
                {
                    new DbParameter("AccessRequests", dataTable, SqlDbType.Structured),
                    new DbParameter("IsAdd", Add, SqlDbType.Bit)
                };

                object result = AGPDBHelper.ExecuteScalar(
                    ProcedureDictionary.sp_AGP_AccessRequest_BulkInsert_Create,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameter
                );

                return new GlobalResponse
                {
                    data = null,
                    message = AppConstants.ActionSuccess,
                    success = Convert.ToInt32(result) == 1
                };
            }
            catch (Exception ex)
            {
                _logger.LogInformation(AppConstants.ErrorMessage, "BulkAddAccessRequest");

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse()
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(requests);
                var firstCreatedBy = requests.FirstOrDefault()?.CreatedBy.ToString();
                AuditLogRepository.SaveAuditLog(firstCreatedBy, AppConstants.AccessRequest, "BulkAddAccessRequest", reqresMsg, errMsg, innrExMsg);
            }
        }

        public async Task<GlobalResponse> UpdateAccessRequest(AccessRequestUpsertRequest request)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                if (request.Id <= 0)
                {
                    return new GlobalResponse()
                    {
                        errorMessage = "Invalid ID for update.",
                        success = false
                    };
                }

                DbParameter[] dbParameter =
                {
                  new DbParameter("Id", request.Id, SqlDbType.BigInt),
                 new DbParameter("EmployeeName", request.EmployeeName, SqlDbType.NVarChar),
                 new DbParameter("EmployeeId", request.EmployeeId, SqlDbType.NVarChar),
                 new DbParameter("DepartmentName", request.DepartmentName, SqlDbType.NVarChar),
                 new DbParameter("Location", request.Location, SqlDbType.NVarChar),
                 new DbParameter("AccessCategoryId", request.AccessCategoryId, SqlDbType.Int),
                 new DbParameter("Reason", request.Reason, SqlDbType.NVarChar),
                 new DbParameter("IsTemporaryAccess", request.IsTemporaryAccess, SqlDbType.Bit),
                 new DbParameter("AccessDurationInDays", request.AccessDurationInDays ?? (object)DBNull.Value, SqlDbType.Int),
                 new DbParameter("ModifiedBy", request.CreatedBy, SqlDbType.BigInt),
                 new DbParameter("AccessFromDate", request.AccessFromDate, SqlDbType.DateTime),
                 new DbParameter("AccessToDate", request.AccessToDate, SqlDbType.DateTime),
                 new DbParameter("ModifiedOn", request.ModifiedOn, SqlDbType.DateTime),
                 new DbParameter("CreatedByEmail",   request.CreatedByEmail, SqlDbType.NVarChar)
                };

                int rowsAffected = AGPDBHelper.ExecuteNonQuery(ProcedureDictionary.sp_AGP_TrustedDomain_Update, DBConnection.AGP_ConStr, CommandType.StoredProcedure, dbParameter);

                if (rowsAffected > 0)
                {
                    _logger.LogInformation(AppConstants.successMessage, "UpdateTrustedDomain");

                    return new GlobalResponse
                    {
                        data = await GetAccessRequestByCode(request.Id),
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        errorMessage = "No records were updated.",
                        success = false
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateTrustedDomain", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse()
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(request);
                AuditLogRepository.SaveAuditLog(request.CreatedBy.ToString(), AppConstants.AccessRequest, "UpdateAccessRequest", reqresMsg, errMsg, innrExMsg);
            }
        }

        public async Task<GlobalResponse> DeleteAccessRequest(long id)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                DbParameter[] dbParameter =
                  {
                  new DbParameter("Id", id, SqlDbType.BigInt),
                 new DbParameter("ModifiedOn", DateTime.UtcNow, SqlDbType.DateTime)
                };

                int rowsAffected = AGPDBHelper.ExecuteNonQuery(ProcedureDictionary.sp_AGP_TrustedDomain_Update, DBConnection.AGP_ConStr, CommandType.StoredProcedure, dbParameter);

                if (rowsAffected > 0)
                {
                    _logger.LogInformation(AppConstants.successMessage, "UpdateTrustedDomain");

                    return new GlobalResponse
                    {
                        errorMessage = "Success.",
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        errorMessage = "No records were updated.",
                        success = false
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateTrustedDomain", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse()
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(id);
               
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.AccessRequest, "DeleteAccessRequest", reqresMsg, errMsg, innrExMsg);
            }
        }

        public async Task<GlobalResponse> GetAccessRequestByEmployeeId(long EmployeeId)
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                DbParameter[] dbParameter =
                  {
                    new DbParameter("EmployeeId", EmployeeId, SqlDbType.BigInt)
                  };

                var resultSet = AGPDBHelper.ExecuteMappedReader<AccessRequest>(ProcedureDictionary.sp_AGP_AccessRequest_GetByEmployeeId,
                               DBConnection.AGP_ConStr, CommandType.StoredProcedure, dbParameter);

                var succeed = resultSet != null && resultSet.Any();
                return new GlobalResponse
                {
                    data = resultSet,
                    message = succeed ? AppConstants.ActionSuccess : AppConstants.NoRecordFound,
                    success = succeed,
                    totalCount = succeed ? resultSet.Count() : null,
                };

            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetAccessRequestByEmployeeId", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse()
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(EmployeeId);
                AuditLogRepository.SaveAuditLog(EmployeeId.ToString(), AppConstants.AccessRequest, "GetAccessRequestByEmployeeId", reqresMsg, errMsg, innrExMsg);
            }
        }

        private DataTable ToAccessRequestDataTable(List<AccessRequestUpsertRequest> requests)
        {
            var table = new DataTable();
            table.Columns.Add("EmployeeName", typeof(string));
            table.Columns.Add("EmployeeId", typeof(string));
            table.Columns.Add("DepartmentName", typeof(string));
            table.Columns.Add("Location", typeof(string));
            table.Columns.Add("AccessCategoryId", typeof(int));
            table.Columns.Add("Reason", typeof(string));
            //new modification
            table.Columns.Add("UploadedFilePath", typeof(string));
            table.Columns.Add("UploadedFileName", typeof(string));

            table.Columns.Add("Status", typeof(string));
            table.Columns.Add("IsTemporaryAccess", typeof(bool));
            table.Columns.Add("AccessDurationInDays", typeof(int));
            table.Columns.Add("CreatedBy", typeof(long));
            table.Columns.Add("AccessFromDate", typeof(DateTime));
            table.Columns.Add("AccessToDate", typeof(DateTime));
            table.Columns.Add("SerialNumber", typeof(string));
            table.Columns.Add("CreatedByEmail", typeof(string));
            foreach (var r in requests)
            {
                table.Rows.Add(
                    r.EmployeeName,
                    r.EmployeeId,
                    r.DepartmentName,
                    r.Location,
                    r.AccessCategoryId,
                    r.Reason,
                    r.UploadedFilePath ?? "",
                     r.UploadedFileName ?? "",
                    r.Status,
                    r.IsTemporaryAccess,
                    r.AccessDurationInDays ?? (object)DBNull.Value,
                    r.CreatedBy,
                    r.AccessFromDate,
                    r.AccessToDate,
                    r.SerialNumber
                );
            }

            return table;
        }

        public Task<GlobalResponse> GetAccessRequestByCode(long code)
        {
            throw new NotImplementedException();
        }

        public Task<GlobalResponse> SearchAccessRequestPagewise(GlobalSearchRequest model)
        {
            throw new NotImplementedException();
        }

        public async Task<GlobalResponse> GetAccessRequestsCreatedBy(long createdBy)
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                if (createdBy <= 0)
                {
                    return new GlobalResponse
                    {
                        errorMessage = "Invalid CreatedBy ID.",
                        success = false
                    };
                }

                DbParameter[] dbParameters =
                {
                  new DbParameter("CreatedBy", createdBy, SqlDbType.BigInt)
                };

                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_GetAllAccessRequests_CreatedBy,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    var accessrequests = dt.AsEnumerable()
                                           .Select(row => new AccessRequestUpsertRequest
                                           {    Id= Convert.ToInt64(row["Id"]),
                                               EmployeeName = row["EmployeeName"].ToString(),
                                               EmployeeId = row["EmployeeId"].ToString(),
                                               DepartmentName = row["DepartmentName"].ToString(),
                                               Location = row["Location"].ToString(),
                                               IsTemporaryAccess = Convert.ToBoolean(row["IsTemporaryAccess"]),
                                               CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                               AccessCategoryId = Convert.ToInt32(row["AccessCategoryId"]),
                                               Status = row["Status"].ToString(),
                                           }).ToList();

                    return new GlobalResponse
                    {
                        data = accessrequests,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No data found for the provided CreatedBy.",
                        success = true,
                        data = new List<AccessRequestUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetAccessRequestByCreatedBy", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(createdBy);
                AuditLogRepository.SaveAuditLog(createdBy.ToString(), AppConstants.AccessRequest, "GetAccessRequestsCreatedBy", reqresMsg, errMsg, innrExMsg);
            }
        }



        /// <summary>
        /// to get access categories
        /// </summary>
        /// <returns></returns>
        public async Task<GlobalResponse> GetCategories()
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_GetAccessCategoryNames,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure
                );

                if (dt != null && dt.Rows.Count > 0)
                {

                    var accessCategories = dt.AsEnumerable()
                        .Select(row => new AccessCategories
                        {
                            Id = row.Field<int>("Id"),
                            Name = row.Field<string>("Name"),
                          
                        })
                        .ToList();

                    return new GlobalResponse
                    {
                        data = accessCategories,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No data found.",
                        success = true,
                        data = new List<AccessCategories>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetCategories");

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.AccessRequest, "GetCategories", string.Empty, errMsg, innrExMsg);
            }
        }

        /// <summary>
        /// to get locations
        /// </summary>
        /// <returns></returns>
        public async Task<GlobalResponse> GetLocations()
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_Locations_GetAll,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    var locations = dt.AsEnumerable()
                        .Select(row => new Locations
                        {
                            Id = row.Field<int>("Id"),
                            CityName = row.Field<string>("CityName")
                        })
                        .ToList();

                    return new GlobalResponse
                    {
                        data = locations,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No data found.",
                        success = true,
                        data = new List<Locations>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetLocations");

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.AccessRequest, "GetLocations", "", errMsg, innrExMsg);
            }
        }


        /// <summary>
        /// to get fh access requests
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        //working method on 11/08/2025
        public async Task<GlobalResponse> GetAccessRequestForFH(string EmployeeId)
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                DbParameter[] dbParameters =
                {
                  new DbParameter("EmployeeId", EmployeeId, SqlDbType.VarChar)
                };

                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_FH_AccessRequest_GetByEmpId,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    var accessrequests = dt.AsEnumerable()
                                           .Select(row => new AccessRequestUpsertRequest
                                           {
                                               Id = row["Id"] == DBNull.Value ? 0 : Convert.ToInt64(row["Id"]),
                                               EmployeeName = row["EmployeeName"] == DBNull.Value ? string.Empty : row["EmployeeName"].ToString(),
                                               EmployeeId = row["EmployeeId"] == DBNull.Value ? string.Empty : row["EmployeeId"].ToString(),
                                               DepartmentName = row["DepartmentName"] == DBNull.Value ? string.Empty : row["DepartmentName"].ToString(),
                                               Location = row["Location"] == DBNull.Value ? string.Empty : row["Location"].ToString(),
                                               AccessCategoryName = row["Name"] == DBNull.Value ? string.Empty : row["Name"].ToString(),
                                               IsTemporaryAccess = row["IsTemporaryAccess"] != DBNull.Value && Convert.ToBoolean(row["IsTemporaryAccess"]),
                                               CreatedBy = row["CreatedBy"] == DBNull.Value ? 0 : Convert.ToInt64(row["CreatedBy"]),
                                               AccessFromDate = row["AccessFromDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["AccessFromDate"]),
                                               AccessToDate = row["AccessToDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["AccessToDate"]),
                                               AccessDurationInDays = row["AccessDurationInDays"] == DBNull.Value ? (int?)null : Convert.ToInt32(row["AccessDurationInDays"]),
                                               AccessCategoryId = row["AccessCategoryId"] == DBNull.Value ? 0 : Convert.ToInt32(row["AccessCategoryId"]),
                                               Reason = row["Reason"] == DBNull.Value ? string.Empty : row["Reason"].ToString(),
                                               Status = row["Status"] == DBNull.Value ? string.Empty : row["Status"].ToString(),
                                           }).ToList();

                    return new GlobalResponse
                    {
                        data = accessrequests,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No data found for the provided CreatedBy.",
                        success = true,
                        data = new List<AccessRequestUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetAccessRequestByCreatedBy", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(EmployeeId);
                AuditLogRepository.SaveAuditLog(EmployeeId, AppConstants.AccessRequest, "GetAccessRequestForFH", reqresMsg, errMsg, innrExMsg);
            }
        }


        public async Task<GlobalResponse> GetAllDraftAccessRequests(string EmployeeId)
        {
            try
            {
                DbParameter[] dbParameters =
                {
                  new DbParameter("EmployeeId", EmployeeId, SqlDbType.VarChar)
                };

                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_GetAllDraftAccessRequests,
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    dbParameters
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    var accessrequests = dt.AsEnumerable()
                                           .Select(row => new AccessRequestUpsertRequest
                                           {
                                               Id = Convert.ToInt64(row["Id"]),
                                               EmployeeName = row["EmployeeName"].ToString(),
                                               EmployeeId = row["EmployeeId"].ToString(),
                                               DepartmentName = row["DepartmentName"].ToString(),
                                               Location = row["Location"].ToString(),
                                               IsTemporaryAccess = Convert.ToBoolean(row["IsTemporaryAccess"]),
                                               CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                               AccessDurationInDays = row["AccessDurationInDays"] == DBNull.Value ? 0 : Convert.ToInt32(row["AccessDurationInDays"]),
                                               AccessCategoryId = Convert.ToInt32(row["AccessCategoryId"]),
                                               AccessCategoryName = row["AccessCategoryName"].ToString(),
                                               Reason = row["Reason"].ToString(),
                                               Status = row["Status"].ToString(),
                                               AccessFromDate = row["AccessFromDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["AccessFromDate"]),
                                               AccessToDate = row["AccessToDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["AccessToDate"]),

                                               //new modification
                                               UploadedFileName = row.Table.Columns.Contains("UploadedFileName") && row["UploadedFileName"] != DBNull.Value
            ? row["UploadedFileName"].ToString()
            : "-",
                                               UploadedFilePath = row.Table.Columns.Contains("UploadedFilePath") && row["UploadedFilePath"] != DBNull.Value
            ? row["UploadedFilePath"].ToString()
            : null

                                           }).ToList();

                    return new GlobalResponse
                    {
                        data = accessrequests,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No data found for the provided CreatedBy.",
                        success = true,
                        data = new List<AccessRequestUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetAccessRequestByCreatedBy", ex);

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
        }

        //Approve Status from Functional Head
        public async Task<GlobalResponse> UpdateStatusToApproved(long id,string justification)
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                if (id <= 0)
                {
                    return new GlobalResponse
                    {
                        success = false,
                        errorMessage = "Invalid AccessRequest ID."
                    };
                }

                using (var conn = new SqlConnection(DBConnection.AGP_ConStr))
                using (var cmd = new SqlCommand("sp_AGP_AccessRequest_UpdateStatus", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@NewStatus", "APPROVED");
                    cmd.Parameters.AddWithValue("@Justification",
                      string.IsNullOrWhiteSpace(justification) ? DBNull.Value : justification);
                    cmd.Parameters.AddWithValue("@ModifiedBy", DBNull.Value);
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();

                    return rowsAffected > 0
                        ? new GlobalResponse { success = true, message = "Status updated to 'Approved' successfully." }
                        : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToApproved", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    success = false,
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(id);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.AccessRequest, "UpdateStatusToApproved", reqresMsg, errMsg, innrExMsg);
            }
        }

        //Approve stattus from IT Team

        public async Task<GlobalResponse> UpdateStatusToApprovedFromIT(long id, string justification)
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                if (id<=0)
                {
                    return new GlobalResponse
                    {
                        success = false,
                        errorMessage = "Invalid Access request ID."
                    };
                }

                using (var conn = new SqlConnection(DBConnection.AGP_ConStr))
                using (var cmd = new SqlCommand("sp_AGP_AccessRequest_UpdateStatus_FromIT", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@NewStatus", "COMPLETED");
                    cmd.Parameters.AddWithValue("@Justification",
                      string.IsNullOrWhiteSpace(justification) ? DBNull.Value : justification);
                    cmd.Parameters.AddWithValue("@ModifiedBy", DBNull.Value);
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();

                    return rowsAffected > 0
                        ? new GlobalResponse { success = true, message = "Status updated to 'Completed' successfully." }
                        : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToComplete", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    success = false,
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(id);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.AccessRequest, "UpdateStatusToApprovedFromIT", reqresMsg, errMsg, innrExMsg);
            }
        }


        //to reject from IT Team

        public async Task<GlobalResponse> UpdateStatusToRejectFromIT(long id, string justification)
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                if (id <= 0)
                {
                    return new GlobalResponse
                    {
                        success = false,
                        errorMessage = "Invalid Access request ID."
                    };
                }

                using (var conn = new SqlConnection(DBConnection.AGP_ConStr))
                using (var cmd = new SqlCommand("sp_AGP_AccessRequest_UpdateStatus_FromIT", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@NewStatus", "REJECTED");
                    cmd.Parameters.AddWithValue("@Justification",
                      string.IsNullOrWhiteSpace(justification) ? DBNull.Value : justification);
                    cmd.Parameters.AddWithValue("@ModifiedBy", DBNull.Value);
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();

                    return rowsAffected > 0
                        ? new GlobalResponse { success = true, message = "Status updated to 'Rejected' successfully." }
                        : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToReject", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    success = false,
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(id);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.AccessRequest, "UpdateStatusToApprovedFromIT", reqresMsg, errMsg, innrExMsg);
            }
        }





        //To reject Access Request
        public async Task<GlobalResponse> UpdateStatusToReject(long id, string justification)
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                if (id <= 0)
                {
                    return new GlobalResponse
                    {
                        success = false,
                        errorMessage = ""
                    };
                }

                using (var conn = new SqlConnection(DBConnection.AGP_ConStr))
                using (var cmd = new SqlCommand("sp_AGP_AccessRequest_UpdateStatus", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@NewStatus", "REJECTED");
                    cmd.Parameters.AddWithValue("@Justification",
                      string.IsNullOrWhiteSpace(justification) ? DBNull.Value : justification);
                    cmd.Parameters.AddWithValue("@ModifiedBy", DBNull.Value);
                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();

                    return rowsAffected > 0
                        ? new GlobalResponse { success = true, message = "Status updated to 'Rejected' successfully." }
                        : new GlobalResponse { success = false, errorMessage = "No record found to update or update failed." };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "UpdateStatusToReject", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    success = false,
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message)
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(id);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.AccessRequest, "UpdateStatusToReject", reqresMsg, errMsg, innrExMsg);
            }
        }

        // to get all requests for functional head
        public async Task<GlobalResponse> ApprovedAccessRequests()
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_AccessRequests_Get_Approved, // SP without CreatedBy filter
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    null // No parameters needed
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    var accessRequests = dt.AsEnumerable()
                                           .Select(row => new AccessRequestUpsertRequest
                                           {
                                               Id = Convert.ToInt64(row["Id"]),
                                               EmployeeName = row["EmployeeName"].ToString(),
                                               EmployeeId = row["EmployeeId"].ToString(),
                                               DepartmentName = row["DepartmentName"].ToString(),
                                               Location = row["Location"].ToString(),
                                               IsTemporaryAccess = Convert.ToBoolean(row["IsTemporaryAccess"]),
                                               CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                               AccessCategoryId = Convert.ToInt32(row["AccessCategoryId"]),
                                               AccessFromDate = Convert.ToDateTime(row["AccessFromDate"]),
                                               AccessToDate = Convert.ToDateTime(row["AccessToDate"]),
                                               //FHActionDate = Convert.ToDateTime(row["FHActionDate"]),
                                               //SubmissionDate = Convert.ToDateTime(row["SubmissionDate"]),
                                               FHActionDate = row["FHActionDate"] == DBNull.Value? (DateTime?)null: Convert.ToDateTime(row["FHActionDate"]),

                                               SubmissionDate = row["SubmissionDate"] == DBNull.Value? (DateTime?)null: Convert.ToDateTime(row["SubmissionDate"]),
                                               AccessCategoryName = row["AccessCategoryName"]?.ToString(),
                                               Status = row["Status"].ToString(),
                                               SerialNumber = row["SerialNumber"].ToString(),
                                               Reason= row["Reason"].ToString(),
                                               Justification = row["Justification"].ToString()
                                               // Add other fields as needed
                                           }).ToList();

                    return new GlobalResponse
                    {
                        data = accessRequests,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No access requests found.",
                        success = true,
                        data = new List<AccessRequestUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetAllAccessRequests", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.AccessRequest, "ApprovedAccessRequests", "", errMsg, innrExMsg);
            }
        }


        // to get Only Approved Requests from Functional Head
        public async Task<GlobalResponse> ApprovedAccessRequestsForIT()
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_AccessRequests_Get_Approved_ForIT, // SP without CreatedBy filter
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    null // No parameters needed
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    var accessRequests = dt.AsEnumerable()
                                           .Select(row => new AccessRequestUpsertRequest
                                           {
                                               Id = Convert.ToInt64(row["Id"]),
                                               EmployeeName = row["EmployeeName"].ToString(),
                                               EmployeeId = row["EmployeeId"].ToString(),
                                               DepartmentName = row["DepartmentName"].ToString(),
                                               AccessCategoryName = row["AccessCategoryName"].ToString(),
                                               Location = row["Location"].ToString(),
                                               IsTemporaryAccess = Convert.ToBoolean(row["IsTemporaryAccess"]),
                                               CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                               AccessCategoryId = Convert.ToInt32(row["AccessCategoryId"]),
                                               Status = row["Status"].ToString(),
                                               Reason = row["Reason"].ToString(),
                                               AccessFromDate = Convert.ToDateTime(row["AccessFromDate"]),
                                               AccessToDate = Convert.ToDateTime(row["AccessToDate"])

                                               // Add other fields as needed
                                           }).ToList();

                    return new GlobalResponse
                    {
                        data = accessRequests,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No access requests found.",
                        success = true,
                        data = new List<AccessRequestUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetAllAccessRequests", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.AccessRequest, "ApprovedAccessRequestsForIT", "", errMsg, innrExMsg);
            }
        }

        //get All Completed request for IT
        public async Task<GlobalResponse> CompletedAccessRequests()
        {
            string errMsg = "";
            string innrExMsg = "";

            try
            {
                DataTable dt = AGPDBHelper.ExecuteDataTable(
                    ProcedureDictionary.sp_AGP_AccessRequests_Get_Completed, // SP without CreatedBy filter
                    DBConnection.AGP_ConStr,
                    CommandType.StoredProcedure,
                    null // No parameters needed
                );

                if (dt != null && dt.Rows.Count > 0)
                {
                    var accessRequests = dt.AsEnumerable()
                                           .Select(row => new AccessRequestUpsertRequest
                                           {
                                               Id = Convert.ToInt64(row["Id"]),
                                               EmployeeName = row["EmployeeName"].ToString(),
                                               EmployeeId = row["EmployeeId"].ToString(),
                                               DepartmentName = row["DepartmentName"].ToString(),
                                               Location = row["Location"]?.ToString(),
                                              // Location = row["LocationName"]?.ToString() ?? row["Location"]?.ToString(),
                                               IsTemporaryAccess = Convert.ToBoolean(row["IsTemporaryAccess"]),
                                               CreatedBy = Convert.ToInt64(row["CreatedBy"]),
                                               AccessCategoryId = Convert.ToInt32(row["AccessCategoryId"]),
                                               ITStatus = row["ITStatus"].ToString(),
                                               Reason = row["Reason"]?.ToString(),
                                               Justification = row["Justification"]?.ToString(),
                                               // Add other fields as needed
                                           }).ToList();

                    return new GlobalResponse
                    {
                        data = accessRequests,
                        message = AppConstants.ActionSuccess,
                        success = true
                    };
                }
                else
                {
                    return new GlobalResponse
                    {
                        message = "No access requests found.",
                        success = true,
                        data = new List<AccessRequestUpsertRequest>()
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetAllAccessRequests", ex);

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.AccessRequest, "CompletedAccessRequests", "", errMsg, innrExMsg);
            }
        }

    }
}
