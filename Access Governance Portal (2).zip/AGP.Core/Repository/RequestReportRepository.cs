﻿using AGP.Core.IRepository;
using AGP.Core.ModelMapper;
using AGP.Core.Service;
using AGP.Data.BaseRepositories;
using AGP.Data.DataContext;
using AGP.Data.DBHelper;
using AGP.Data.Entity;
using AGP.Data.UnitOfWork;
using AGP.Data.ViewModels.BaseModels;
using AGP.Data.ViewModels.RequestReportModel;
using Azure;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.Repository
{
    public class RequestReportRepository : IRequestReportRepository
    {
        private readonly AGPDBContext _dbContext;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IHelper _helper;
        private readonly IMapperFactory _mapperFactory;
        private IRepository<TrustedDomain> _trustedDomain;
        private readonly ILogger<TrustedDomainRepository> _logger;
        private readonly ICurrentUserService _currentUser;

        public RequestReportRepository(IMapperFactory mapperFactory, IUnitOfWork unitOfWork,
            ILogger<TrustedDomainRepository> logger,
            //IAuditLogRepository auditLogRepository,
            AGPDBContext dbContext,
            IHelper helper,
            ICurrentUserService currentUser
            )
        {
            _mapperFactory = mapperFactory;
            _unitOfWork = unitOfWork;
            _dbContext = dbContext;
            _helper = helper;
            _trustedDomain = _unitOfWork.GetRepository<TrustedDomain>();
            _logger = logger;
            _currentUser = currentUser;
        }

        public async Task<RequestReportResponse> GetRequestsByEmployeeId(EmployeeRequestFilter filter)
        {
            string errMsg = "";
            string innrExMsg = "";
            int? totalRecords = null;
            List<AccessRequestReportModel> accessRequestReportModels = new();
            List<TrustedDomainReportModel> trusetedRequestReportModels = new();
            EmployeeRequestModel empReq = new();
            try
            {
                DbParameter[] parameters =
                {
                  new DbParameter(AppConstants.EmployeeId , filter.EmployeeId, SqlDbType.NVarChar),
                  new DbParameter(AppConstants.Status , (object?)filter.Status ?? DBNull.Value, SqlDbType.NVarChar),
                  new DbParameter(AppConstants.FromDate , (object?)filter.FromDate ?? DBNull.Value, SqlDbType.DateTime),
                  new DbParameter(AppConstants.ToDate , (object?)filter.ToDate ?? DBNull.Value, SqlDbType.DateTime)

                };

                var resultSet = AGPDBHelper.ExecuteMultiReader(
                             ProcedureDictionary.sp_AGP_EmployeeRequests_GetAll,
                             DBConnection.AGP_ConStr, 
                             CommandType.StoredProcedure, 
                             parameters);

                if (resultSet != null && resultSet.Tables.Count > 0 && resultSet.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in resultSet.Tables[0].Rows)
                    {
                        var model = new AccessRequestReportModel
                        {
                            Id = row.Field<long>("Id"),
                            EmployeeName = row.Field<string>("EmployeeName"),
                            EmployeeId = row.Field<string>("EmployeeId"),
                            DepartmentName = row.Field<string>("DepartmentName"),
                            Location = row.Field<string>("Location"),
                            AccessCategoryName = row.Field<string>("AccessCategoryName"), 
                          //  AccessCategoryId = row.Field<int>("AccessCategoryId"),
                            Reason = row.Field<string>("Reason"),
                            IsTemporaryAccess = row.Field<bool>("IsTemporaryAccess"),
                            AccessDurationInDays = row.Field<int?>("AccessDurationInDays"),
                            UploadedFileName = row.Field<string>("UploadedFileName"),
                            UploadedFilePath = row.Field<string>("UploadedFilePath"),
                            Justification = row.Field<string>("Justification"),
                            Remark = row.Field<string>("Remark"),
                            SubmissionDate = row.Field<DateTime?>("SubmissionDate"),
                            Status = row.Field<string>("Status"),
                            CreatedBy = row.Field<long>("CreatedBy"),
                            AccessFromDate = row.Field<DateTime?>("AccessFromDate"),
                            AccessToDate = row.Field<DateTime?>("AccessToDate"),
                            CreatedOn = row.Field<DateTime?>("CreatedOn"),
                            SerialNumber = row.Field<string>("SerialNumber"),
                        };

                        accessRequestReportModels.Add(model);
                    }
                }
                if (resultSet != null && resultSet.Tables.Count > 0 && resultSet.Tables[1].Rows.Count > 0)
                {
                    foreach (DataRow row in resultSet.Tables[1].Rows)
                    {
                        var model = new TrustedDomainReportModel
                        {
                            Id = row.Field<long>("Id"),
                            DomainCompanyName = row.Field<string>("DomainCompanyName"),
                            RelationshipWithKSB = row.Field<string>("RelationshipWithKSB"),
                            DomainOrEmail = row.Field<string>("DomainOrEmail"),
                            WhitelistType = row.Field<string>("WhitelistType"),
                            StartDate = row.Field<DateTime?>("StartDate"),
                            EndDate = row.Field<DateTime?>("EndDate"),
                            Justification = row.Field<string>("Justification"),
                            Remark = row.Field<string>("Remark"),
                            SubmissionDate = row.Field<DateTime?>("SubmissionDate"),
                            Status = row.Field<string>("Status"),
                            CreatedBy = row.Field<string>("CreatedBy"),
                            CreatedOn = row.Field<DateTime?>("CreatedOn"),
                            AccessDurationInDays = row.Field<int?>("AccessDurationInDays"),
                            SerialNumber = row.Field<string>("SerialNumber")
                        };

                        trusetedRequestReportModels.Add(model);
                    }
                }
                bool hasData = accessRequestReportModels.Count > 0 || trusetedRequestReportModels.Count > 0;
                return new RequestReportResponse
                {
                    accessRequest = accessRequestReportModels,
                    trustedDomainRequest = trusetedRequestReportModels,
                    accessRequestCount = accessRequestReportModels?.Count ?? 0,
                    trustedDomainRequestCount = trusetedRequestReportModels?.Count ?? 0,
                    message = hasData ? AppConstants.ActionSuccess : AppConstants.NoRecordFound,
                    success = hasData
                };

            }
            catch (Exception ex)
            {
                _logger.LogError(AppConstants.ErrorMessage, "GetRequestByEmployeeId", ex);
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new RequestReportResponse
                {
                    message = string.Format(AppConstants.ErrorMessage, ex?.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(filter);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.RequestReport, "GetRequestsByEmployeeId", reqresMsg, errMsg, innrExMsg);
            }
        }

    }
}
