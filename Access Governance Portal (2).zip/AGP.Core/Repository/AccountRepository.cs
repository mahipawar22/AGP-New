﻿using AGP.Core.IRepository;
using AGP.Core.ModelMapper;
using AGP.Core.Service;
using AGP.Data.BaseRepositories;
using AGP.Data.DataContext;
using AGP.Data.DBHelper;
using AGP.Data.Entity;
using AGP.Data.UnitOfWork;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using Azure.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data;

namespace AGP.Core.Repository
{
    public class AccountRepository : IAccountRepository
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly AGPDBContext _context;
        private readonly IMapperFactory _mapperFactory;
        private IRepository<MasterUser> _userRepository;
        private IRepository<Role> _roleRepository;
        private IRepository<Menu> _menuRepository;
        private IRepository<MenuRolePermission> _rolepermissionRepository;
        private readonly ILogger<AccountRepository> _logger;
        protected readonly IHelper helper;
        private readonly IConfiguration _configuration;
        private readonly ICurrentUserService _currentUser;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public AccountRepository(IMapperFactory mapperFactory, 
            IUnitOfWork unitOfWork, 
            IHelper _helper,
            ILogger<AccountRepository> logger,
            AGPDBContext context, 
            IConfiguration configuration,
            ICurrentUserService currentUser
            )
        {
            _mapperFactory = mapperFactory;
            _unitOfWork = unitOfWork;
            _userRepository = _unitOfWork.GetRepository<MasterUser>();
            _roleRepository = _unitOfWork.GetRepository<Role>();
            _rolepermissionRepository = _unitOfWork.GetRepository<MenuRolePermission>();
            _menuRepository = _unitOfWork.GetRepository<Menu>();
            _logger = logger;
            helper = _helper;
            _context = context;
            _configuration = configuration;
            _currentUser = currentUser;
        }

        public async Task<MasterUserModel> Login(LoginModel model)
        {
            MasterUserModel userModel = new MasterUserModel();
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                model.IsSSO = true; 
                DbParameter[] osqlParameter =
                {
                  new DbParameter("EmployeeId", model.UserId, SqlDbType.VarChar),
                  new DbParameter("Password", (model.Password ?? "0"), SqlDbType.VarChar),
                  new DbParameter("IsSSO", model.IsSSO, SqlDbType.Bit)
                };

                var Results = AGPDBHelper.ExecuteMultiReader(ProcedureDictionary.sp_AGP_User_Login,
                                 DBConnection.AGP_ConStr, CommandType.StoredProcedure, osqlParameter);

                if(Results == null || Results.Tables[0].Rows.Count == 0)
                {
                    return null;
                }
                if (Results != null && Results.Tables.Count > 0)
                {
                    userModel = Results.Tables[0].DataTableToList<MasterUserModel>().FirstOrDefault();
                    userModel.ListPermission = Results.Tables[1].DataTableToList<UserPermissionModel>();

                    if(userModel.RoleId == 2)
                    {
                        if (Results.Tables.Count > 2)
                        {
                            var empIds = Results.Tables[2].AsEnumerable()
                                .Select(row => row.Field<string>("ReportingEmpids"))
                                .Where(empId => !string.IsNullOrEmpty(empId))
                                .ToList();

                            userModel.ReportingEmpids = string.Join(",", empIds);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                _logger.LogError(ex, ex.Message);
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(model);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
            return userModel;
        }

        public Task<MasterUserLoginModel> Login2FA(LoginModel model)
        {
            throw new NotImplementedException();
        }

        public Task<MasterUserModel> LoginDetailsFor2FA(string email)
        {
            throw new NotImplementedException();
        }

        public Task<GlobalResponse> Resetpassword(ResetPasswordModel model)
        {
            throw new NotImplementedException();
        }

        public Task<GlobalResponse> Forgotpassword(ForgotPasswordModel forgotPasswordModel)
        {
            throw new NotImplementedException();
        }

        public Task<GlobalResponse> GetLoggedInUserEntity()
        {
            throw new NotImplementedException();
        }

        public Task<GlobalResponse> GetUserPermissions(int userId)
        {
            throw new NotImplementedException();
        }

       
    }
}
