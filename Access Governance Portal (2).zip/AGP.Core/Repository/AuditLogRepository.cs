﻿using AGP.Data.DBHelper;
using AGP.Data.ViewModels.BaseModels;
using Azure.Core;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.Repository
{
    public static class AuditLogRepository
    {
        public static void SaveAuditLog(string createdBy, string moduleName, string action, string reqResMsg, string errMsg, string innrEx)
        {
            try
            {
                var dbParameter = new DbParameter[]
                {
                    new DbParameter("ModuleName", moduleName ?? (object)DBNull.Value, SqlDbType.NVarChar),
                    new DbParameter("ModuleAction", action ?? (object)DBNull.Value, SqlDbType.NVarChar),
                    new DbParameter("CreatedBy", createdBy ?? (object)DBNull.Value, SqlDbType.NVarChar),
                    new DbParameter("RequestResponseMsg", reqResMsg ?? (object)DBNull.Value, SqlDbType.NVarChar),
                    new DbParameter("ExceptionMessage", errMsg ?? (object)DBNull.Value, SqlDbType.NVarChar),
                    new DbParameter("InnerException", innrEx ?? (object)DBNull.Value, SqlDbType.NVarChar)
                };

                object result = AGPDBHelper.ExecuteScalar(
                    ProcedureDictionary.sp_AGP_AuditLog_Insert,
                    DBConnection.AGP_ConStr, CommandType.StoredProcedure, dbParameter);

            }
            catch (Exception ex)
            {
            }
        }
    }
}
