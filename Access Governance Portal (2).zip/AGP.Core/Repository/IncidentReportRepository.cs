﻿using AGP.Core.IRepository;
using AGP.Core.Service;
using AGP.Data.DBHelper;
using AGP.Data.Entity;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using AGP.Data.ViewModels.DlpIncident;
using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
//using System.Web.UI;
//using System.Web.UI.WebControls;

using static System.Net.Mime.MediaTypeNames;

namespace AGP.Core.Repository
{
    public class IncidentReportRepository: IIncidentRepostRopository
    {
        private readonly ICurrentUserService _currentUser;

        public IncidentReportRepository(ICurrentUserService currentUser)
        {
            _currentUser = currentUser;
        }

        public async Task<GlobalResponse> UploadFile(IFormFile file)
        {
            var response = new GlobalResponse();
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                if (file == null || file.Length == 0)
                {
                    response.success = false;
                    response.errorMessage = "No file uploaded or file is empty.";
                    return response;
                }

                var incidents = new List<DlpIncidentReport>();

                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    stream.Position = 0;

                    using (var package = new ExcelPackage(stream))
                    {
                        var worksheet = package.Workbook.Worksheets[0];
                        int rowCount = worksheet.Dimension.Rows;

                        // Reading data from the Excel file
                        for (int row = 2; row <= rowCount; row++)
                        {
                            var rawIncidentTime = worksheet.Cells[row, 2].Text?.Trim();
                            Console.WriteLine($"Row {row}: Raw IncidentTime value = '{rawIncidentTime}'");

                            DateTime? parsedIncidentTime = null;

                            // Try to clean the value (remove timezone)
                            var cleanTime = rawIncidentTime?.Split("GMT")[0].Trim();

                            string[] formats = {
                               "dd MMM. yyyy, hh:mm:ss tt", // e.g. 21 Jun. 2025, 03:56:07 PM
                                    "dd MMM yyyy, hh:mm:ss tt"   // fallback if dot (.) is missing
};

                            if (DateTime.TryParseExact(cleanTime, formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsed))
                            {
                                parsedIncidentTime = parsed;
                            }
                            else
                            {
                                Console.WriteLine($"[WARN] Could not parse IncidentTime on row {row}: '{rawIncidentTime}'");
                            }
                            var incident = new DlpIncidentReport
                            {
                                IncidentId = long.TryParse(worksheet.Cells[row, 1].Text, out var incidentId) ? incidentId : 0,
                                IncidentTime = parsedIncidentTime,
                                SourceChannel = worksheet.Cells[row, 3].Text,   // Source
                                Destination = worksheet.Cells[row, 5].Text,     // Destination
                                ActionTaken = worksheet.Cells[row, 6].Text,     // Action
                                TransactionSize = decimal.TryParse(worksheet.Cells[row, 7].Text, out var size) ? (int)size : 0,
                                FileName = worksheet.Cells[row, 8].Text,

                                // Names/Emails instead of numeric Ids
                                UserName = worksheet.Cells[row, 9].Text?.Trim(),
                                SourceEmailID = worksheet.Cells[row, 10].Text?.Trim(),
                                Location = worksheet.Cells[row, 11].Text?.Trim(),
                                DepartmentName = worksheet.Cells[row, 12].Text?.Trim(),
                                FunctionalHeadName = worksheet.Cells[row, 13].Text?.Trim(),

                            };
                            incidents.Add(incident);
                        }
                    }
                }

                // Pass the list of incidents for bulk insert
                response = await InsertDLPIncidentsAsync(incidents);

            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";

                response.success = false;
                response.errorMessage = $"Internal server error: {ex.Message}";
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.IncidentReport, "UploadIncidentFile", reqresMsg, errMsg, innrExMsg);
            }
            return response;
        }

        public async Task<GlobalResponse> InsertDLPIncidentsAsync(List<DlpIncidentReport> incidents)
        {
            var response = new GlobalResponse();

            string errMsg = "";
            string innrExMsg = "";

            try
            {
                using (var conn = new SqlConnection(DBConnection.AGP_ConStr))
                {
                    await conn.OpenAsync();

                    // Create DataTable to match the TVP structure
                    var dt = new DataTable();
                    dt.Columns.Add("IncidentId", typeof(string));
                    dt.Columns.Add("IncidentTime", typeof(DateTime)).AllowDBNull = true;
                    dt.Columns.Add("SourceChannel", typeof(string));
                    dt.Columns.Add("Destination", typeof(string));
                    dt.Columns.Add("ActionTaken", typeof(string));
                    dt.Columns.Add("TransactionSize", typeof(int));
                    dt.Columns.Add("FileName", typeof(string));
                    dt.Columns.Add("UserId", typeof(long));
                    dt.Columns.Add("Location", typeof(string));
                    dt.Columns.Add("DepartmentId", typeof(int));
                    dt.Columns.Add("FunctionalHeadId", typeof(long)).AllowDBNull = true;
                    dt.Columns.Add("Acknowledgement", typeof(string));
                    dt.Columns.Add("Justification", typeof(string));
                    dt.Columns.Add("CreatedBy", typeof(string));
                    dt.Columns.Add("CreatedOn", typeof(DateTime));
                    dt.Columns.Add("ModifiedBy", typeof(string));
                    dt.Columns.Add("ModifiedOn", typeof(DateTime)).AllowDBNull = true;
                    dt.Columns.Add("IsDeleted", typeof(bool));
                    dt.Columns.Add("UserName", typeof(string));
                    dt.Columns.Add("DepartmentName", typeof(string));
                    dt.Columns.Add("FunctionalHeadName", typeof(string));
                    dt.Columns.Add("SourceEmailId", typeof(string));


                    // Add each incident from the list to the DataTable
                    foreach (var incident in incidents)
                    {
                        dt.Rows.Add(
                            incident.IncidentId,
                            incident.IncidentTime,
                            incident.SourceChannel,
                            incident.Destination,
                            incident.ActionTaken,
                            incident.TransactionSize,
                            incident.FileName,
                            incident.UserId,
                            incident.Location,
                            incident.DepartmentId,
                            incident.FunctionalHeadId,
                            incident.Acknowledgement,
                            incident.Justification,
                            incident.CreatedBy,
                            incident.CreatedOn,
                            incident.ModifiedBy,
                            incident.ModifiedOn,
                            incident.IsDeleted,
                            incident.UserName,
                            incident.DepartmentName,
                            incident.FunctionalHeadName,
                            incident.SourceEmailID
                        );
                    }
                    string jsonData = JsonConvert.SerializeObject(incidents);
                    using (var cmd = new SqlCommand("sp_AGP_DLPIncident_Upload_Bulk", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Add JSON parameter (use NVARCHAR(MAX))
                        var param = cmd.Parameters.Add("@JsonData", SqlDbType.NVarChar, -1);
                        param.Value = jsonData;

                        await cmd.ExecuteNonQueryAsync();
                    }

                    response.success = true;
                    response.message = "Data inserted successfully.";
                }
            }
            catch (Exception ex)
            {
                response.success = false;
                response.errorMessage = $"Error inserting data: {ex.Message}";

                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject(incidents);
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.IncidentReport, "InsertDLPIncidentsAsync", reqresMsg, errMsg, innrExMsg);
            }
            return response;
        }


        public async Task<GlobalResponse> GetDlpReportByDate()
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                // Run the synchronous method on a background thread
                var resultSet = await Task.Run(() =>
                    AGPDBHelper.ExecuteMappedReader<DlpIncidentReportNew>(
                        ProcedureDictionary.sp_AGP_DLPIncidents_GetByDate,
                        DBConnection.AGP_ConStr,
                        CommandType.StoredProcedure
                    )
                );

                bool succeed = resultSet != null && resultSet.Any();

                return new GlobalResponse
                {
                    data = resultSet,
                    message = succeed ? AppConstants.ActionSuccess : AppConstants.NoRecordFound,
                    success = succeed,
                    totalCount = succeed ? resultSet.Count : 0
                };
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }

        public async Task<GlobalResponse> GetDlpReport(string employeeId)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                if (string.IsNullOrWhiteSpace(employeeId))
                {
                    return new GlobalResponse
                    {
                        errorMessage = "Invalid Employee ID.",
                        success = false
                    };
                }

                DbParameter[] dbParameters =
                {
                  new DbParameter("EmployeeId", employeeId, SqlDbType.VarChar)
                };

                var resultSet = await Task.Run(() =>
                    AGPDBHelper.ExecuteMappedReader<DlpIncidentReportNew>(
                        ProcedureDictionary.sp_AGP_FH_GetAllDLPIncidentReport,
                        DBConnection.AGP_ConStr,
                        CommandType.StoredProcedure, dbParameters
                    )
                );

                bool succeed = resultSet != null && resultSet.Any();

                return new GlobalResponse
                {
                    data = resultSet,
                    message = succeed ? AppConstants.ActionSuccess : AppConstants.NoRecordFound,
                    success = succeed,
                    totalCount = succeed ? resultSet.Count : 0
                };
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }


        //for that user
        public async Task<GlobalResponse> GetDlpReportforUser(string employeeId)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                if (string.IsNullOrWhiteSpace(employeeId))
                {
                    return new GlobalResponse
                    {
                        errorMessage = "Invalid Employee ID.",
                        success = false
                    };
                }

                DbParameter[] dbParameters =
                {
                  new DbParameter("EmployeeId", employeeId, SqlDbType.VarChar)
                };
                // Run the synchronous method on a background thread
                var resultSet = await Task.Run(() =>
                    AGPDBHelper.ExecuteMappedReader<DlpIncidentReportNew>(
                        ProcedureDictionary.sp_AGP_DlpIncidentsByEmployeeId,
                        DBConnection.AGP_ConStr,
                        CommandType.StoredProcedure,
                        dbParameters
                    )
                );

                bool succeed = resultSet != null && resultSet.Any();

                return new GlobalResponse
                {
                    data = resultSet,
                    message = succeed ? AppConstants.ActionSuccess : AppConstants.NoRecordFound,
                    success = succeed,
                    totalCount = succeed ? resultSet.Count : 0
                };
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    errorMessage = string.Format(AppConstants.ErrorMessage, ex.Message),
                    success = false
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }

        public async Task<GlobalResponse> UpdateIncidentReportFromFH([FromBody] IncidentReportApprove request)
        {
            string errMsg = "";
            string innrExMsg = "";
            try
            {
                if (request == null )
                {
                    return new GlobalResponse
                    {
                        success = false,
                        message = "No incident IDs provided.",
                        data = null
                    };
                }

                // request is already List<int>
                string idListString = string.Join(",", request.Id);

                if (request.decision == "Acknowledgement")
                {
                    DbParameter[] dbParameters =
                    {
                      new DbParameter("Ids", idListString, SqlDbType.NVarChar),
                      new DbParameter("Acknowledgement", request.Acknowledgement  ?? string.Empty, SqlDbType.NVarChar)
                    };
                    object result = AGPDBHelper.ExecuteScalar(
                        "dbo.sp_AGP_DLPIncident_UpdateAcknowledgementBulk",
                        DBConnection.AGP_ConStr,
                        CommandType.StoredProcedure,
                        dbParameters
                    );
                    return new GlobalResponse
                    {
                        success = true,
                        message = "Acknowledgement updated successfully.",
                        data = null
                    };
                }
                else 
                {
                    DbParameter[] dbParameters =
                    {
                         new DbParameter("Ids", idListString, SqlDbType.NVarChar),
                         new DbParameter("Justification", request.Justification ?? string.Empty, SqlDbType.NVarChar)
                    };
                    object result = AGPDBHelper.ExecuteScalar(
                        "dbo.sp_AGP_DLPIncident_UpdateJustificationBulk",
                        DBConnection.AGP_ConStr,
                        CommandType.StoredProcedure,
                        dbParameters
                    );
                    return new GlobalResponse
                    {
                        success = true,
                        message = "Justification updated successfully.",
                        data = null
                    };
                }
            }
            catch (Exception ex)
            {
                errMsg = ex.Message;
                innrExMsg = ex.InnerException != null ? ex.InnerException.Message : "";
                return new GlobalResponse
                {
                    success = false,
                    errorMessage = $"Error updating incidents: {ex.Message}",
                    data = null
                };
            }
            finally
            {
                string reqresMsg = JsonConvert.SerializeObject("Incedine Report file upload");
                AuditLogRepository.SaveAuditLog(_currentUser.GetUserId().ToString(), AppConstants.Login, "Login", reqresMsg, errMsg, innrExMsg);
            }
        }
    }
}
