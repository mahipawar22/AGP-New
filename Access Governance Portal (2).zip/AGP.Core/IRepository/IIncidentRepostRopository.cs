﻿using AGP.Data.ViewModels;
using AGP.Data.ViewModels.AccessRequest;
using AGP.Data.ViewModels.BaseModels;
using AGP.Data.ViewModels.DlpIncident;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.IRepository
{
    public interface IIncidentRepostRopository
    {
        Task<GlobalResponse> UploadFile(IFormFile file);
        Task<GlobalResponse> GetDlpReportByDate();
        Task<GlobalResponse> GetDlpReport(string employeeId);
        Task<GlobalResponse> GetDlpReportforUser(string employeeId);
        Task<GlobalResponse> UpdateIncidentReportFromFH(IncidentReportApprove request);
    }
}
