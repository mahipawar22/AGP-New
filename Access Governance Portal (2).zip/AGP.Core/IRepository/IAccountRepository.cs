﻿using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.IRepository
{
    public interface IAccountRepository
    {
        Task<MasterUserModel> Login(LoginModel model);
        Task<GlobalResponse> GetUserPermissions(int userId);
        Task<GlobalResponse> GetLoggedInUserEntity();
        //Task<GlobalResponse> GetMenuByModule(int moduleId);
        Task<MasterUserModel> LoginDetailsFor2FA(string email);
        Task<MasterUserLoginModel> Login2FA(LoginModel model);

        Task<GlobalResponse> Forgotpassword(ForgotPasswordModel forgotPasswordModel);
        Task<GlobalResponse> Resetpassword(ResetPasswordModel model);
    }
}
