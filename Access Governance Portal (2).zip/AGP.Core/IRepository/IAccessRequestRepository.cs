﻿using AGP.Data.ViewModels;
using AGP.Data.ViewModels.AccessRequest;
using AGP.Data.ViewModels.BaseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.IRepository
{
    public interface IAccessRequestRepository
    {
        Task<GlobalResponse> GetAccessRequestByCode(long code);
        Task<GlobalResponse> GetAccessRequestByEmployeeId(long EmployeeId);
        Task<GlobalResponse> SearchAccessRequestPagewise(GlobalSearchRequest model);
        Task<GlobalResponse> AddAccessRequest(AccessRequestUpsertRequest request);
        Task<GlobalResponse> BulkAddAccessRequest(List<AccessRequestUpsertRequest> request, bool Add);
        Task<GlobalResponse> UpdateAccessRequest(AccessRequestUpsertRequest request);
        Task<GlobalResponse> DeleteAccessRequest(long id);
        Task<GlobalResponse> GetAccessRequestsCreatedBy(long id);
        Task<GlobalResponse> UpdateStatusToApproved(long id,string justification);
        Task<GlobalResponse> ApprovedAccessRequests();
        Task<GlobalResponse> UpdateStatusToReject(long id, string justification);
        Task<GlobalResponse> GetAccessRequestForFH(string employeeid);
        Task<GlobalResponse> GetAllDraftAccessRequests(string employeeid);
        Task<GlobalResponse> UpdateStatusToApprovedFromIT(long employeeid,string justification);
        Task<GlobalResponse> UpdateStatusToRejectFromIT(long employeeid,string justification);
        //Task<GlobalResponse> UpdateStatusToApprovedFromIT(long employeeid);
        Task<GlobalResponse> CompletedAccessRequests();
        Task<GlobalResponse> ApprovedAccessRequestsForIT();
        Task<GlobalResponse> GetCategories();
        Task<GlobalResponse> GetLocations();
    }
}
