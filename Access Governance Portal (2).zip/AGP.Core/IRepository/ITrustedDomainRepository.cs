﻿using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using AGP.Data.ViewModels.TrustedDomain;
using Microsoft.AspNetCore.Http;

namespace AGP.Core.IRepository
{
    public interface ITrustedDomainRepository
    {
        Task<GlobalResponse> GetTrustedDomainByCode(long code);
        Task<GlobalResponse> GetTrustedDomainCreatedBy(long Createdby);
        Task<GlobalResponse> SearchTrustedDomainPagewise(GlobalSearchRequest model);
        Task<GlobalResponse> AddOrUpdateTrustedDomain(TrustedDomainUpsertRequest request);
        Task<GlobalResponse> BulkAddTrustedDomainRequest(List<TrustedDomainUpsertRequest> requests, bool Add);
        Task<GlobalResponse> DeleteTrustedDomain(long id, int ModifiedBy);
       // Task<GlobalResponse> UpdateStatusToApproved(List<TrustedDomainUpsertRequest> requests);
        Task<GlobalResponse> UpdateStatusToApproved(long id,string justification);
       // Task<GlobalResponse> UpdateStatusToApproved(long id);
        Task<GlobalResponse> UpdateStatusToRejectFromFH(long id,string justification);
        Task<GlobalResponse> UpdateStatusToRejectFromDlp(long id,string justification);
       // Task<GlobalResponse> ApprovedTrustedDomainRequests(int id);
        Task<GlobalResponse> ApprovedTrustedDomainRequests();
        Task<GlobalResponse> GetTrustedDomainForFH(string employeeid);
        Task<GlobalResponse> GetALlDraftTDRequests(string employeeid);
        //Task<GlobalResponse> UpdateStatusToApprovedFromDlp(List<TrustedDomainStatusUpdate> requests); //(long id);
        Task<GlobalResponse> UpdateStatusToApprovedFromDlp(long id,string justification); //(long id);
        Task<GlobalResponse> CompletedTrustedDomainRequests();
        Task<GlobalResponse> ApprovedTrustedDomainRequestsForDlp();
        
    }
}
