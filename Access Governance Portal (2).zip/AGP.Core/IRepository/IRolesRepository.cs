﻿using AGP.Core.Repository;
using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.IRepository
{
    public interface IRolesRepository 
    {
        Task<GlobalResponse> GetAll(GlobalSearchRequest model);
        Task<GlobalResponse> GetByRoleId(int RoleId);
        Task<GlobalResponse> CreateOrUpdateAsync(RolePermissionRequest request);
        Task<GlobalResponse> RemovePermissions(int roleId, int permissionId);
        Task<GlobalResponse> GetRolesAsync(GlobalSearchRequest model);
        Task<GlobalResponse> GetMenusAsync(GlobalSearchRequest model);
        Task<GlobalResponse> GetPermissionsAsync(GlobalSearchRequest model);
    }
}
