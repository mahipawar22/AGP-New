﻿using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;

namespace AGP.Core.IRepository
{
    public interface IMasterSystemDownTimeRepository
    {
        Task<GlobalResponse> GetSystemDownTime();
        Task<GlobalResponse> AddOrUpdateMasterSystemDownTime(MasterSystemDownTimeModel model);
    }
}
