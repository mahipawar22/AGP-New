﻿using AGP.Data.ViewModels;
using AGP.Data.ViewModels.BaseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.IRepository
{
    public interface IUserRepository
    {
        Task<GlobalResponse> GetUsersAsync(GlobalSearchRequest model);
        Task<GlobalResponse> GetUserByIdAsync(int Id);
        Task<GlobalResponse> UpdateRoleAsync(string employeeId, int roleId, long modifiedBy);
        Task<GlobalResponse> DeactivateUserAsync(DeactivateUserRequest employeeId);
        Task<GlobalResponse> AddUserAsync(AddUserRequest model);
        Task<GlobalResponse> GetEmployeeFromAscent(string employeeId, string name);
    }
}
