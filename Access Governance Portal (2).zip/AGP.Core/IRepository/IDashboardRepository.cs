﻿using AGP.Data.ViewModels.BaseModels;
using AGP.Data.ViewModels.RequestReportModel;

namespace AGP.Core.IRepository
{
    public interface IDashboardRepository
    {
        Task<GlobalResponse> GetRequestsByEmployeeId(string EmployeeId);
    }
}
