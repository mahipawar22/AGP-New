﻿using AGP.Data.ViewModels.BaseModels;
using AGP.Data.ViewModels.RequestReportModel;

namespace AGP.Core.IRepository
{
    public interface IRequestReportRepository
    {
        Task<RequestReportResponse> GetRequestsByEmployeeId(EmployeeRequestFilter filter);
    }
}
