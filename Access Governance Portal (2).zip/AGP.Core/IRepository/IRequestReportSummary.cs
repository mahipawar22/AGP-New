﻿using AGP.Data.ViewModels.RequestReportModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.IRepository
{
    public interface IRequestReportSummary
    {
        Task<RequestReportSummaryModel> GetRequestsByEmployeeId(string EmployeeId);
    }
}
