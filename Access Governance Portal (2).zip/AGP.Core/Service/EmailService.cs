﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace AGP.Core.Service
{
    public static class EmailService
    {
        public static void SendEmail(IConfiguration configuration, string fromEmail, String toEmail)
        {

            if (configuration["Smtp:IsTestEmail"].ToString() == "true")
            {
                fromEmail = configuration["Smtp:fromEmail"].ToString();
                toEmail = configuration["Smtp:toEmail"].ToString();
            }
            string ccEmail = configuration["Smtp:ccEmail"].ToString();
            string subject = configuration["Smtp:subject"].ToString();
            string body = configuration["Smtp:body"].ToString();

            using (MailMessage mail = new MailMessage())
            {
                mail.From = new MailAddress(fromEmail);

                if (!string.IsNullOrWhiteSpace(toEmail))
                    mail.To.Add(toEmail);

                if (!string.IsNullOrWhiteSpace(ccEmail))
                {
                    foreach (var email in ccEmail.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        mail.CC.Add(email.Trim());
                    }
                }
                if (!string.IsNullOrWhiteSpace(ccEmail))
                {
                    foreach (var email in ccEmail.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
                    {

                        mail.CC.Add(email.Trim());
                    }

                }

                mail.Subject = subject;
                mail.Body = body;
                mail.IsBodyHtml = true;
                //using (SmtpClient smtp = new SmtpClient(configuration["Smtp:SmtpHost"].ToString(), int.Parse(configuration["Smtp:Port"].ToString())))
                //{
                //    smtp.Credentials = new NetworkCredential(configuration["Smtp:NetWorkUserName"].ToString(), configuration["Smtp:NetWorkPassword"].ToString());
                //    smtp.EnableSsl = true;
                //    smtp.Timeout = 30000;
                //    mail.Subject = subject;
                //    mail.Body = body;
                //    mail.IsBodyHtml = true;
                    using (SmtpClient smtp = new SmtpClient(configuration["Smtp:Host"].ToString(), int.Parse(configuration["Smtp:Port"].ToString())))
                    {
                        smtp.Credentials = new NetworkCredential(
                       configuration["Smtp:Username"],
                       configuration["Smtp:Password"]);
                        smtp.EnableSsl = true;
                        smtp.Timeout = 30000;

                        smtp.Send(mail);
                    }
                //}
            }
        }
    }
}
