﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace AGP.Core.Service
{


    public interface ICurrentUserService
    {
        long? GetUserId();
        string GetUserName();
        string GetEmail();
    }

    public class CurrentUserService : ICurrentUserService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CurrentUserService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public long? GetUserId()
        {
            var userIdClaim = _httpContextAccessor.HttpContext?.User?.FindFirst("UserId")?.Value;
            if (long.TryParse(userIdClaim, out var id))
                return id;

            return null;
        }

        public string GetUserName()
        {
            return _httpContextAccessor.HttpContext?.User?.FindFirst("UserName")?.Value ?? string.Empty;
        }

        public string GetEmail()
        {
            return _httpContextAccessor.HttpContext?.User?.FindFirst("Email")?.Value ?? string.Empty;
        }
    }

}
